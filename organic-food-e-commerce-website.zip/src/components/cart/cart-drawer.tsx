"use client";

// ---------------------------------------------------------------------------
// Slide-over cart drawer with quantity controls, free-shipping progress and a
// lightweight checkout that posts to /api/orders.
// ---------------------------------------------------------------------------
import { AnimatePresence, motion } from "framer-motion";
import {
  CheckCircle2,
  Leaf,
  Loader2,
  Minus,
  Plus,
  ShoppingBasket,
  Trash2,
  Truck,
  X,
} from "lucide-react";
import Image from "next/image";
import { useState } from "react";
import { useCart } from "@/components/cart/cart-context";
import { formatPrice } from "@/lib/utils";

const FREE_SHIPPING_AT = 49;
const FLAT_SHIPPING = 5.9;

type Phase = "cart" | "sending" | "done" | "error";

export function CartDrawer() {
  const {
    lines,
    subtotal,
    isOpen,
    closeCart,
    setQuantity,
    removeItem,
    clear,
  } = useCart();
  const [phase, setPhase] = useState<Phase>("cart");
  const [orderRef, setOrderRef] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const shipping = subtotal === 0 || subtotal >= FREE_SHIPPING_AT ? 0 : FLAT_SHIPPING;
  const total = subtotal + shipping;
  const progress = Math.min(100, (subtotal / FREE_SHIPPING_AT) * 100);

  async function checkout() {
    if (!lines.length || !name.trim() || !email.trim()) return;
    setPhase("sending");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: name.trim(),
          customerEmail: email.trim(),
          items: lines.map((l) => ({ productId: l.id, quantity: l.quantity })),
        }),
      });
      if (!res.ok) throw new Error("Order failed");
      const data = (await res.json()) as { orderNumber?: string };
      setOrderRef(data.orderNumber ?? "AAC-000000");
      setPhase("done");
      clear();
    } catch {
      setPhase("error");
    }
  }

  function resetAndClose() {
    closeCart();
    // Let the exit animation finish before resetting the view state.
    setTimeout(() => setPhase("cart"), 400);
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={closeCart}
            className="fixed inset-0 z-[70] bg-forest-950/55 backdrop-blur-sm"
            aria-hidden="true"
          />
          {/* Panel */}
          <motion.aside
            key="panel"
            role="dialog"
            aria-label="Shopping cart"
            initial={{ x: "105%" }}
            animate={{ x: 0 }}
            exit={{ x: "105%" }}
            transition={{ type: "spring", stiffness: 320, damping: 34 }}
            className="fixed inset-y-0 right-0 z-[80] flex w-full max-w-md flex-col bg-cream-50 shadow-2xl shadow-forest-950/30"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-forest-900/10 px-6 py-5">
              <h2 className="flex items-center gap-2.5 font-display text-xl font-semibold text-forest-950">
                <ShoppingBasket className="size-5 text-clay-500" aria-hidden />
                Your basket
              </h2>
              <button
                onClick={closeCart}
                aria-label="Close cart"
                className="focus-ring rounded-full p-2 text-forest-700 transition hover:bg-forest-50 hover:text-forest-950"
              >
                <X className="size-5" aria-hidden />
              </button>
            </div>

            {/* ---------- Success state ---------- */}
            {phase === "done" ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
                <motion.div
                  initial={{ scale: 0.6, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", stiffness: 260, damping: 18 }}
                >
                  <CheckCircle2 className="size-16 text-forest-500" aria-hidden />
                </motion.div>
                <h3 className="font-display text-2xl font-semibold text-forest-950">
                  Shukran! Order received.
                </h3>
                <p className="text-sm leading-relaxed text-forest-700">
                  Your reference is{" "}
                  <span className="font-semibold text-clay-600">{orderRef}</span>.
                  A confirmation is on its way to your inbox, and your box ships
                  within 24 hours.
                </p>
                <button
                  onClick={resetAndClose}
                  className="focus-ring mt-2 rounded-full bg-forest-800 px-7 py-3 text-sm font-semibold text-cream-50 transition hover:bg-forest-900"
                >
                  Continue shopping
                </button>
              </div>
            ) : lines.length === 0 ? (
              /* ---------- Empty state ---------- */
              <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
                <div className="flex size-20 items-center justify-center rounded-full bg-forest-50">
                  <Leaf className="size-9 text-forest-400" aria-hidden />
                </div>
                <h3 className="font-display text-2xl font-semibold text-forest-950">
                  Your basket is empty
                </h3>
                <p className="text-sm text-forest-700">
                  Fill it with honest food — honey, olive oil, dates and more,
                  straight from the farms.
                </p>
                <a
                  href="/products"
                  onClick={closeCart}
                  className="focus-ring mt-2 rounded-full bg-clay-500 px-7 py-3 text-sm font-semibold text-cream-50 transition hover:bg-clay-600"
                >
                  Browse the harvest
                </a>
              </div>
            ) : (
              /* ---------- Cart contents ---------- */
              <>
                {/* Free-shipping progress */}
                <div className="border-b border-forest-900/10 px-6 py-4">
                  <p className="flex items-center gap-2 text-xs font-semibold tracking-wide text-forest-800 uppercase">
                    <Truck className="size-4 text-clay-500" aria-hidden />
                    {shipping === 0
                      ? "You've unlocked free shipping"
                      : `${formatPrice(FREE_SHIPPING_AT - subtotal)} away from free shipping`}
                  </p>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-forest-100">
                    <motion.div
                      className="h-full rounded-full bg-gradient-to-r from-forest-500 to-clay-500"
                      animate={{ width: `${progress}%` }}
                      transition={{ type: "spring", stiffness: 120, damping: 20 }}
                    />
                  </div>
                </div>

                {/* Lines */}
                <ul className="flex-1 divide-y divide-forest-900/8 overflow-y-auto px-6">
                  <AnimatePresence initial={false}>
                    {lines.map((line) => (
                      <motion.li
                        key={line.id}
                        layout
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: 40 }}
                        className="flex gap-4 py-4"
                      >
                        <div className="relative size-16 shrink-0 overflow-hidden rounded-xl bg-cream-200">
                          <Image
                            src={line.image}
                            alt={line.alt}
                            fill
                            sizes="64px"
                            className="object-cover"
                          />
                        </div>
                        <div className="flex flex-1 flex-col">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="text-sm font-semibold text-forest-950">
                                {line.name}
                              </p>
                              <p className="text-xs text-forest-600">{line.unit}</p>
                            </div>
                            <button
                              onClick={() => removeItem(line.id)}
                              aria-label={`Remove ${line.name}`}
                              className="focus-ring rounded-full p-1.5 text-forest-400 transition hover:bg-clay-100 hover:text-clay-600"
                            >
                              <Trash2 className="size-4" aria-hidden />
                            </button>
                          </div>
                          <div className="mt-auto flex items-center justify-between pt-2">
                            <div className="flex items-center rounded-full border border-forest-900/15">
                              <button
                                onClick={() => setQuantity(line.id, line.quantity - 1)}
                                aria-label={`Decrease quantity of ${line.name}`}
                                className="focus-ring p-1.5 text-forest-700 transition hover:text-clay-600"
                              >
                                <Minus className="size-3.5" aria-hidden />
                              </button>
                              <span className="w-7 text-center text-sm font-semibold text-forest-950">
                                {line.quantity}
                              </span>
                              <button
                                onClick={() => setQuantity(line.id, line.quantity + 1)}
                                aria-label={`Increase quantity of ${line.name}`}
                                className="focus-ring p-1.5 text-forest-700 transition hover:text-forest-500"
                              >
                                <Plus className="size-3.5" aria-hidden />
                              </button>
                            </div>
                            <p className="text-sm font-bold text-forest-950">
                              {formatPrice(Number(line.price) * line.quantity)}
                            </p>
                          </div>
                        </div>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>

                {/* Checkout */}
                <div className="border-t border-forest-900/10 bg-cream-100/70 px-6 py-5">
                  <div className="space-y-1.5 text-sm">
                    <div className="flex justify-between text-forest-700">
                      <span>Subtotal</span>
                      <span className="font-medium">{formatPrice(subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-forest-700">
                      <span>Shipping</span>
                      <span className="font-medium">
                        {shipping === 0 ? "Free" : formatPrice(shipping)}
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-forest-900/10 pt-2 text-base font-bold text-forest-950">
                      <span>Total</span>
                      <span>{formatPrice(total)}</span>
                    </div>
                  </div>
                  <div className="mt-4 grid gap-2">
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Full name"
                      aria-label="Full name"
                      className="focus-ring w-full rounded-xl border border-forest-900/15 bg-cream-50 px-4 py-2.5 text-sm text-forest-950 placeholder:text-forest-400"
                    />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Email address"
                      aria-label="Email address"
                      className="focus-ring w-full rounded-xl border border-forest-900/15 bg-cream-50 px-4 py-2.5 text-sm text-forest-950 placeholder:text-forest-400"
                    />
                    {phase === "error" && (
                      <p className="text-xs font-medium text-clay-600">
                        Something went wrong placing your order — please try again.
                      </p>
                    )}
                    <button
                      onClick={checkout}
                      disabled={phase === "sending" || !name.trim() || !email.trim()}
                      className="focus-ring mt-1 flex w-full items-center justify-center gap-2 rounded-full bg-clay-500 px-6 py-3.5 text-sm font-bold text-cream-50 transition hover:bg-clay-600 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {phase === "sending" ? (
                        <>
                          <Loader2 className="size-4 animate-spin" aria-hidden />
                          Placing your order…
                        </>
                      ) : (
                        <>Place order · {formatPrice(total)}</>
                      )}
                    </button>
                    <p className="text-center text-[11px] text-forest-500">
                      Farm-fresh guarantee · 30-day Amanah Promise
                    </p>
                  </div>
                </div>
              </>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
