// ---------------------------------------------------------------------------
// Infinite marquee strip — pure CSS animation, pauses on hover. Server-safe.
// ---------------------------------------------------------------------------
import { Sparkle } from "lucide-react";

export function Marquee({ items }: { items: string[] }) {
  // Duplicate the list so the -50% translate loop is seamless.
  const loop = [...items, ...items];
  return (
    <div
      className="overflow-hidden border-y border-cream-100/10 bg-forest-900 py-4"
      aria-hidden
    >
      <div className="flex w-max animate-marquee items-center gap-8 pr-8 hover:[animation-play-state:paused]">
        {loop.map((item, i) => (
          <span
            key={i}
            className="flex items-center gap-8 text-sm font-semibold tracking-[0.22em] whitespace-nowrap text-cream-100/85 uppercase"
          >
            {item}
            <Sparkle className="size-4 text-honey-300" aria-hidden />
          </span>
        ))}
      </div>
    </div>
  );
}
