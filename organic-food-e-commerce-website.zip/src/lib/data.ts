// ---------------------------------------------------------------------------
// Data-access layer: reads from PostgreSQL via Drizzle, with graceful fallback
// to bundled seed content so the site never renders empty.
// ---------------------------------------------------------------------------
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { faqs, products, reviews } from "@/db/schema";
import {
  fallbackFaqs,
  fallbackProducts,
  fallbackReviews,
  type FaqData,
  type ProductData,
  type ReviewData,
} from "@/lib/fallback-data";

function toProduct(row: {
  id: number;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  category: string;
  price: string;
  unit: string;
  image: string;
  alt: string;
  badge: string | null;
  rating: string;
  stock: number;
  featured: boolean;
  sort: number;
}): ProductData {
  return { ...row };
}

/** All products, ordered for display. */
export async function getProducts(): Promise<ProductData[]> {
  try {
    const rows = await db.select().from(products).orderBy(asc(products.sort));
    return rows.length ? rows.map(toProduct) : fallbackProducts;
  } catch {
    return fallbackProducts;
  }
}

/** Featured products for the home page showcase. */
export async function getFeaturedProducts(): Promise<ProductData[]> {
  try {
    const rows = await db
      .select()
      .from(products)
      .where(eq(products.featured, true))
      .orderBy(asc(products.sort));
    return rows.length
      ? rows.map(toProduct)
      : fallbackProducts.filter((p) => p.featured);
  } catch {
    return fallbackProducts.filter((p) => p.featured);
  }
}

/** Customer reviews for testimonials sections. */
export async function getReviews(): Promise<ReviewData[]> {
  try {
    const rows = await db.select().from(reviews).orderBy(asc(reviews.sort));
    return rows.length ? rows : fallbackReviews;
  } catch {
    return fallbackReviews;
  }
}

/** FAQs grouped in display order. */
export async function getFaqs(): Promise<FaqData[]> {
  try {
    const rows = await db.select().from(faqs).orderBy(asc(faqs.sort));
    return rows.length ? rows : fallbackFaqs;
  } catch {
    return fallbackFaqs;
  }
}
