"use client";

// ---------------------------------------------------------------------------
// Product card: image with hover zoom, badge, rating, price and add-to-cart
// with micro-confirmation feedback.
// ---------------------------------------------------------------------------
import { motion } from "framer-motion";
import { Check, Plus } from "lucide-react";
import Image from "next/image";
import { useEffect, useState } from "react";
import { useCart } from "@/components/cart/cart-context";
import { Stars } from "@/components/shared/stars";
import type { ProductData } from "@/lib/fallback-data";
import { cn, formatPrice } from "@/lib/utils";

export function ProductCard({
  product,
  index = 0,
}: {
  product: ProductData;
  index?: number;
}) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  // Reset the "+ Added" confirmation after a moment.
  useEffect(() => {
    if (!added) return;
    const t = setTimeout(() => setAdded(false), 1600);
    return () => clearTimeout(t);
  }, [added]);

  return (
    <motion.article
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.7, delay: (index % 4) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -6 }}
      className="group relative flex flex-col overflow-hidden rounded-[28px] border border-forest-900/10 bg-cream-50 shadow-sm shadow-forest-950/5 transition-shadow duration-500 hover:shadow-xl hover:shadow-forest-950/12"
    >
      {/* Image */}
      <div className="relative aspect-[5/4] overflow-hidden bg-cream-200">
        <Image
          src={product.image}
          alt={product.alt}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
        {product.badge && (
          <span className="absolute top-3.5 left-3.5 rounded-full bg-forest-900/90 px-3 py-1.5 text-[10px] font-bold tracking-[0.18em] text-cream-50 uppercase backdrop-blur">
            {product.badge}
          </span>
        )}
      </div>

      {/* Body */}
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center justify-between gap-2">
          <p className="text-[10px] font-bold tracking-[0.22em] text-clay-600 uppercase">
            {product.category}
          </p>
          <Stars rating={Number(product.rating)} starClass="size-3.5" />
        </div>

        <h3 className="mt-2 font-display text-xl leading-snug font-semibold text-forest-950">
          {product.name}
        </h3>
        <p className="mt-1 text-sm leading-relaxed text-forest-600">
          {product.tagline}
        </p>

        <div className="mt-4 flex items-end justify-between gap-3 border-t border-forest-900/8 pt-4">
          <p className="leading-none">
            <span className="font-display text-2xl font-bold text-forest-950">
              {formatPrice(product.price)}
            </span>
            <span className="mt-1 block text-[11px] font-medium text-forest-500">
              {product.unit}
            </span>
          </p>
          <button
            onClick={() => {
              addItem(product);
              setAdded(true);
            }}
            aria-label={`Add ${product.name} to cart`}
            className={cn(
              "focus-ring flex items-center gap-1.5 rounded-full px-4 py-2.5 text-sm font-bold transition-all duration-300",
              added
                ? "bg-forest-500 text-cream-50"
                : "bg-clay-500 text-cream-50 hover:bg-clay-600 active:scale-95",
            )}
          >
            {added ? (
              <>
                <Check className="size-4" aria-hidden /> Added
              </>
            ) : (
              <>
                <Plus className="size-4" aria-hidden /> Add
              </>
            )}
          </button>
        </div>
      </div>
    </motion.article>
  );
}
