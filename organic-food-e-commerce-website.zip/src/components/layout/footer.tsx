// ---------------------------------------------------------------------------
// Footer: newsletter capture, navigation columns, contact details, socials and
// copyright. Server component (the form itself is a small client island).
// ---------------------------------------------------------------------------
import {
  Leaf,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Truck,
} from "lucide-react";
import Link from "next/link";
import { NewsletterForm } from "@/components/layout/newsletter-form";
import {
  FacebookIcon,
  InstagramIcon,
  XSocialIcon,
  YoutubeIcon,
} from "@/components/shared/social-icons";

const SOCIALS = [
  { href: "https://instagram.com/alamanahcart", label: "Instagram", Icon: InstagramIcon },
  { href: "https://facebook.com/alamanahcart", label: "Facebook", Icon: FacebookIcon },
  { href: "https://x.com/alamanahcart", label: "X (Twitter)", Icon: XSocialIcon },
  { href: "https://youtube.com/@alamanahcart", label: "YouTube", Icon: YoutubeIcon },
];

const SHOP_LINKS = [
  { href: "/products", label: "All Products" },
  { href: "/products?category=Honey+%26+Sweets", label: "Honey & Sweets" },
  { href: "/products?category=Pantry", label: "Pantry Staples" },
  { href: "/products?category=Tea+%26+Herbs", label: "Tea & Herbs" },
  { href: "/products?category=Spices", label: "Spices" },
];

const COMPANY_LINKS = [
  { href: "/about", label: "Our Story" },
  { href: "/#reviews", label: "Customer Reviews" },
  { href: "/#faq", label: "FAQ" },
  { href: "/contact", label: "Contact Us" },
];

export function Footer() {
  return (
    <footer className="grain texture-dots relative overflow-hidden bg-forest-950 text-cream-100">
      <div className="relative z-[2] mx-auto max-w-7xl px-5 pt-16 pb-8 md:px-8">
        {/* Newsletter band */}
        <div className="flex flex-col items-start justify-between gap-8 border-b border-cream-100/10 pb-12 lg:flex-row lg:items-center">
          <div className="max-w-lg">
            <p className="flex items-center gap-2 text-xs font-bold tracking-[0.28em] text-honey-300 uppercase">
              <Leaf className="size-4" aria-hidden /> The Harvest Letter
            </p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-cream-50 md:text-4xl">
              Seasonal recipes &amp; farm news, once a month.
            </h2>
          </div>
          <NewsletterForm />
        </div>

        {/* Link columns */}
        <div className="grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <Link href="/" className="focus-ring inline-flex items-center gap-2.5 rounded-full">
              <span className="flex size-10 items-center justify-center rounded-full bg-cream-50 text-forest-900">
                <Leaf className="size-5" aria-hidden />
              </span>
              <span className="leading-none">
                <span className="block font-display text-lg font-semibold tracking-tight text-cream-50">
                  Al Amanah
                </span>
                <span className="block text-[10px] font-bold tracking-[0.32em] text-honey-300 uppercase">
                  Organic Cart
                </span>
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-cream-100/70">
              Certified-organic food sourced directly from small farms — traceable
              to the field, delivered to your door. That is our amanah.
            </p>
            <div className="mt-5 flex gap-2">
              {SOCIALS.map(({ href, label, Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Al Amanah Cart on ${label}`}
                  className="focus-ring flex size-10 items-center justify-center rounded-full border border-cream-100/15 text-cream-100/80 transition hover:border-honey-300 hover:bg-honey-300 hover:text-forest-950"
                >
                  <Icon className="size-4.5" aria-hidden />
                </a>
              ))}
            </div>
          </div>

          {/* Shop */}
          <nav aria-label="Footer shop links">
            <h3 className="text-xs font-bold tracking-[0.28em] text-cream-100/50 uppercase">
              Shop
            </h3>
            <ul className="mt-4 space-y-2.5">
              {SHOP_LINKS.map((l) => (
                <li key={l.label}>
                  <Link
                    href={l.href}
                    className="focus-ring link-underline rounded text-sm text-cream-100/80 transition hover:text-cream-50"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Company */}
          <nav aria-label="Footer company links">
            <h3 className="text-xs font-bold tracking-[0.28em] text-cream-100/50 uppercase">
              Company
            </h3>
            <ul className="mt-4 space-y-2.5">
              {COMPANY_LINKS.map((l) => (
                <li key={l.label}>
                  <Link
                    href={l.href}
                    className="focus-ring link-underline rounded text-sm text-cream-100/80 transition hover:text-cream-50"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Contact */}
          <div>
            <h3 className="text-xs font-bold tracking-[0.28em] text-cream-100/50 uppercase">
              Reach Us
            </h3>
            <ul className="mt-4 space-y-3 text-sm text-cream-100/80">
              <li className="flex items-start gap-2.5">
                <MapPin className="mt-0.5 size-4 shrink-0 text-honey-300" aria-hidden />
                <span>
                  2410 Harvest Lane, Suite 12
                  <br />
                  Austin, TX 78704
                </span>
              </li>
              <li>
                <a href="tel:+15125550134" className="focus-ring flex items-center gap-2.5 rounded transition hover:text-cream-50">
                  <Phone className="size-4 shrink-0 text-honey-300" aria-hidden />
                  +1 (512) 555-0134
                </a>
              </li>
              <li>
                <a href="mailto:hello@alamanahcart.com" className="focus-ring flex items-center gap-2.5 rounded transition hover:text-cream-50">
                  <Mail className="size-4 shrink-0 text-honey-300" aria-hidden />
                  hello@alamanahcart.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Trust strip */}
        <div className="flex flex-wrap items-center gap-x-8 gap-y-3 border-t border-cream-100/10 pt-6 pb-6 text-xs text-cream-100/60">
          <span className="flex items-center gap-2">
            <ShieldCheck className="size-4 text-forest-300" aria-hidden />
            Certified organic · every batch traceable
          </span>
          <span className="flex items-center gap-2">
            <Truck className="size-4 text-forest-300" aria-hidden />
            Free shipping over $49 · 30-day Amanah Promise
          </span>
        </div>

        {/* Copyright bar */}
        <div className="flex flex-col items-center justify-between gap-3 border-t border-cream-100/10 pt-6 text-xs text-cream-100/50 sm:flex-row">
          <p>© {new Date().getFullYear()} Al Amanah Cart. All rights reserved.</p>
          <p>
            Grown with care, shipped with <em className="font-display italic">amanah</em>.
          </p>
        </div>
      </div>

      {/* Giant watermark */}
      <div
        aria-hidden
        className="pointer-events-none relative z-[1] -mb-6 overflow-hidden text-center font-display text-[18vw] leading-[0.8] font-bold tracking-tight text-cream-100/4 select-none md:-mb-10"
      >
        amanah
      </div>
    </footer>
  );
}
