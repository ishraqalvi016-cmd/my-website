"use client";

// ---------------------------------------------------------------------------
// Footer newsletter capture (client island with success state).
// ---------------------------------------------------------------------------
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { useState, type FormEvent } from "react";

export function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  function subscribe(e: FormEvent) {
    e.preventDefault();
    if (!email.includes("@")) return;
    setDone(true);
  }

  if (done) {
    return (
      <p className="flex items-center gap-2.5 rounded-full border border-forest-400/40 bg-forest-900/60 px-6 py-4 text-sm font-medium text-forest-100">
        <CheckCircle2 className="size-5 text-honey-300" aria-hidden />
        You&apos;re on the list — see you at the next harvest.
      </p>
    );
  }

  return (
    <form onSubmit={subscribe} className="w-full max-w-md" aria-label="Newsletter signup">
      <div className="flex items-center gap-2 rounded-full border border-cream-100/20 bg-cream-100/5 p-1.5 backdrop-blur transition focus-within:border-honey-300/60">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Your email address"
          aria-label="Email address for newsletter"
          className="w-full bg-transparent px-4 py-2.5 text-sm text-cream-50 placeholder:text-cream-100/40 focus:outline-none"
        />
        <button
          type="submit"
          aria-label="Subscribe to the Harvest Letter"
          className="focus-ring flex size-11 shrink-0 items-center justify-center rounded-full bg-clay-500 text-cream-50 transition hover:bg-clay-400"
        >
          <ArrowRight className="size-5" aria-hidden />
        </button>
      </div>
      <p className="mt-2.5 pl-4 text-xs text-cream-100/40">
        No spam, ever. Unsubscribe in one click.
      </p>
    </form>
  );
}
