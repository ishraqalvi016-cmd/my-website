// ---------------------------------------------------------------------------
// "Why Al Amanah" values band — four pillars with staggered scroll reveals.
// ---------------------------------------------------------------------------
import { HandHeart, Leaf, Recycle, Truck, type LucideIcon } from "lucide-react";
import { Reveal } from "@/components/shared/reveal";

const VALUES: { Icon: LucideIcon; title: string; body: string }[] = [
  {
    Icon: Leaf,
    title: "Certified Organic",
    body: "No shortcuts, ever. Every product carries USDA or equivalent certification — batch reports on request.",
  },
  {
    Icon: Truck,
    title: "48-Hour Freshness",
    body: "Packed the day they ship in compostable insulation. From the farm gate to your door in two days.",
  },
  {
    Icon: HandHeart,
    title: "The Amanah Promise",
    body: "Not delighted? We refund or replace within 30 days — no questions, no forms, no fine print.",
  },
  {
    Icon: Recycle,
    title: "Zero-Waste Packing",
    body: "Recycled paper, plant-based gel packs, glass over plastic. Packaging that returns to the earth.",
  },
];

export function Values() {
  return (
    <section
      className="border-y border-forest-900/10 bg-forest-50/60"
      aria-label="Our values"
    >
      <div className="mx-auto grid max-w-7xl gap-px overflow-hidden px-5 py-16 md:grid-cols-2 md:px-8 md:py-20 lg:grid-cols-4">
        {VALUES.map(({ Icon, title, body }, i) => (
          <Reveal key={title} delay={i * 0.1} className="h-full">
            <div className="group h-full rounded-3xl border border-transparent p-6 transition-all duration-500 hover:border-forest-900/10 hover:bg-cream-50 hover:shadow-lg hover:shadow-forest-950/6">
              <span className="flex size-12 items-center justify-center rounded-2xl bg-forest-800 text-cream-50 transition-all duration-500 group-hover:rotate-6 group-hover:bg-clay-500">
                <Icon className="size-6" aria-hidden />
              </span>
              <h3 className="mt-5 font-display text-xl font-semibold text-forest-950">
                {title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-forest-700">{body}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
