"use client";

// ---------------------------------------------------------------------------
// FAQ accordion with buttery height animations (framer-motion).
// ---------------------------------------------------------------------------
import { AnimatePresence, motion } from "framer-motion";
import { MessageCircle, Plus } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { Reveal } from "@/components/shared/reveal";
import type { FaqData } from "@/lib/fallback-data";
import { cn } from "@/lib/utils";

export function FaqSection({ faqs }: { faqs: FaqData[] }) {
  const [openId, setOpenId] = useState<number | null>(faqs[0]?.id ?? null);

  return (
    <section
      id="faq"
      className="mx-auto max-w-7xl scroll-mt-24 px-5 py-20 md:px-8 md:py-28"
      aria-label="Frequently asked questions"
    >
      <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        {/* Sticky intro column */}
        <Reveal>
          <div className="lg:sticky lg:top-28">
            <p className="flex items-center gap-3 text-xs font-bold tracking-[0.3em] text-clay-600 uppercase">
              <span aria-hidden className="h-px w-8 bg-clay-600/50" />
              Good questions
            </p>
            <h2 className="mt-4 font-display text-4xl leading-[1.06] font-semibold tracking-tight text-balance text-forest-950 md:text-5xl">
              Everything you&apos;d ask <em className="text-clay-600 italic">a friend</em>
            </h2>
            <p className="mt-4 max-w-md leading-relaxed text-forest-700">
              Sourcing, shipping, returns — told plainly. Still curious about
              something? A real human answers every message within a day.
            </p>
            <Link
              href="/contact"
              className="focus-ring mt-7 inline-flex items-center gap-2.5 rounded-full border border-forest-900/20 bg-cream-50 px-6 py-3.5 text-sm font-bold text-forest-900 transition hover:border-forest-800 hover:bg-forest-800 hover:text-cream-50"
            >
              <MessageCircle className="size-4" aria-hidden />
              Ask us anything
            </Link>
          </div>
        </Reveal>

        {/* Accordion */}
        <div className="space-y-3">
          {faqs.map((faq, i) => {
            const open = openId === faq.id;
            return (
              <Reveal key={faq.id} delay={i * 0.06} y={18}>
                <div
                  className={cn(
                    "overflow-hidden rounded-3xl border transition-colors duration-500",
                    open
                      ? "border-forest-800/25 bg-cream-50 shadow-lg shadow-forest-950/6"
                      : "border-forest-900/10 bg-cream-50/60 hover:bg-cream-50",
                  )}
                >
                  <button
                    onClick={() => setOpenId(open ? null : faq.id)}
                    aria-expanded={open}
                    aria-controls={`faq-answer-${faq.id}`}
                    className="focus-ring flex w-full items-center gap-4 px-6 py-5 text-left"
                  >
                    <span
                      className={cn(
                        "rounded-full px-2.5 py-1 text-[10px] font-bold tracking-[0.16em] uppercase",
                        open
                          ? "bg-clay-100 text-clay-700"
                          : "bg-forest-50 text-forest-600",
                      )}
                    >
                      {faq.category}
                    </span>
                    <span className="flex-1 font-display text-lg font-semibold text-forest-950 md:text-xl">
                      {faq.question}
                    </span>
                    <motion.span
                      animate={{ rotate: open ? 45 : 0 }}
                      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                      className={cn(
                        "flex size-8 shrink-0 items-center justify-center rounded-full transition-colors",
                        open ? "bg-clay-500 text-cream-50" : "bg-forest-800/8 text-forest-800",
                      )}
                    >
                      <Plus className="size-4" aria-hidden />
                    </motion.span>
                  </button>
                  <AnimatePresence initial={false}>
                    {open && (
                      <motion.div
                        id={`faq-answer-${faq.id}`}
                        key="answer"
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                      >
                        <p className="px-6 pb-6 leading-relaxed text-forest-700 md:pl-[7.5rem]">
                          {faq.answer}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
