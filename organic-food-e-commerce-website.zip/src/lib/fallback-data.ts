// ---------------------------------------------------------------------------
// Static fallback content — keeps every page fully rendered even if the
// database is momentarily unavailable (e.g. before `drizzle-kit push` runs).
// The seed script inserts exactly these records.
// ---------------------------------------------------------------------------

export type ProductData = {
  id: number;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  category: string;
  price: string;
  unit: string;
  image: string;
  alt: string;
  badge: string | null;
  rating: string;
  stock: number;
  featured: boolean;
  sort: number;
};

export type ReviewData = {
  id: number;
  name: string;
  location: string;
  rating: number;
  text: string;
  sort: number;
};

export type FaqData = {
  id: number;
  question: string;
  answer: string;
  category: string;
  sort: number;
};

export const PRODUCT_CATEGORIES = [
  "Pantry",
  "Honey & Sweets",
  "Oils",
  "Grains",
  "Tea & Herbs",
  "Spices",
] as const;

export const fallbackProducts: ProductData[] = [
  {
    id: 1,
    name: "Wildflower Raw Honey",
    slug: "wildflower-raw-honey",
    tagline: "Unfiltered, cold-extracted, single apiary",
    description:
      "Harvested from wildflower meadows and never heated above hive temperature, this raw honey keeps every enzyme, pollen grain, and floral note intact. Drizzle over warm bread, yogurt, or aged cheese.",
    category: "Honey & Sweets",
    price: "14.00",
    unit: "450 g jar",
    image: "/images/product-honey.jpg",
    alt: "Glass jar of golden raw wildflower honey with a wooden dipper on a cream backdrop",
    badge: "Bestseller",
    rating: "4.9",
    stock: 120,
    featured: true,
    sort: 1,
  },
  {
    id: 2,
    name: "Cold-Pressed Olive Oil",
    slug: "cold-pressed-olive-oil",
    tagline: "First harvest, estate grown, 0.2% acidity",
    description:
      "Pressed within six hours of picking, our extra-virgin olive oil is grassy, peppery, and alive with polyphenols. Bottled in dark glass to protect it from light and heat.",
    category: "Oils",
    price: "22.00",
    unit: "500 ml bottle",
    image: "/images/product-olive-oil.jpg",
    alt: "Dark glass bottle of cold-pressed organic olive oil with fresh olives beside it",
    badge: "Estate Grown",
    rating: "4.8",
    stock: 80,
    featured: true,
    sort: 2,
  },
  {
    id: 3,
    name: "Medjool Dates",
    slug: "medjool-dates",
    tagline: "Sun-ripened, hand-sorted, naturally sweet",
    description:
      "Plump, caramel-soft Medjool dates grown under desert sun and packed the day they are sorted. No added sugar, no sulphites — just the fruit, exactly as nature intended.",
    category: "Pantry",
    price: "11.50",
    unit: "500 g box",
    image: "/images/product-dates.jpg",
    alt: "Bowl of organic Medjool dates on a warm cream background",
    badge: "New Harvest",
    rating: "4.9",
    stock: 150,
    featured: true,
    sort: 3,
  },
  {
    id: 4,
    name: "Sprouted Grain Granola",
    slug: "sprouted-grain-granola",
    tagline: "Slow-baked with honey & sea salt",
    description:
      "Sprouted oats, almonds, and seeds slow-baked in small batches with raw honey and a whisper of sea salt. Clustery, crunchy, and endlessly giftable.",
    category: "Grains",
    price: "9.50",
    unit: "400 g jar",
    image: "/images/product-granola.jpg",
    alt: "Glass jar of organic sprouted grain granola with oats scattered around",
    badge: null,
    rating: "4.7",
    stock: 90,
    featured: true,
    sort: 4,
  },
  {
    id: 5,
    name: "Chamomile Meadow Tea",
    slug: "chamomile-meadow-tea",
    tagline: "Whole flowers, calming evening blend",
    description:
      "Whole chamomile flowers blended with lemon balm and a touch of lavender. An honest cup of calm, picked at dawn when the blossoms are fullest.",
    category: "Tea & Herbs",
    price: "8.75",
    unit: "60 g tin",
    image: "/images/product-tea.jpg",
    alt: "Tin of organic chamomile herbal tea with dried flowers on cream linen",
    badge: null,
    rating: "4.8",
    stock: 110,
    featured: false,
    sort: 5,
  },
  {
    id: 6,
    name: "Stone-Ground Almond Butter",
    slug: "stone-ground-almond-butter",
    tagline: "One ingredient. Stone-milled for 12 hours.",
    description:
      "Roasted organic almonds and nothing else, milled slowly on granite stones until spoon-soft. Rich, deeply toasty, with the oil rising naturally to the top.",
    category: "Pantry",
    price: "13.25",
    unit: "280 g jar",
    image: "/images/product-almond-butter.jpg",
    alt: "Open jar of stone-ground organic almond butter with whole almonds",
    badge: "Small Batch",
    rating: "4.9",
    stock: 70,
    featured: false,
    sort: 6,
  },
  {
    id: 7,
    name: "Mountain Za'atar Blend",
    slug: "mountain-zaatar-blend",
    tagline: "Wild thyme, sumac & toasted sesame",
    description:
      "Wild thyme gathered from mountain slopes, ground with tart sumac and golden sesame. The blend our grandmother would recognise — fragrant, honest, alive.",
    category: "Spices",
    price: "7.50",
    unit: "90 g jar",
    image: "/images/product-zaatar.jpg",
    alt: "Jar of organic green za'atar spice blend with fresh thyme sprigs",
    badge: "Heritage",
    rating: "4.8",
    stock: 130,
    featured: false,
    sort: 7,
  },
  {
    id: 8,
    name: "Pomegranate Molasses",
    slug: "pomegranate-molasses",
    tagline: "100% juice, reduced over low fire",
    description:
      "Ripe pomegranates pressed and slowly reduced to a garnet-dark syrup. Bright, tangy, and transformative in dressings, marinades, and stews.",
    category: "Pantry",
    price: "12.00",
    unit: "350 ml bottle",
    image: "/images/product-pomegranate.jpg",
    alt: "Bottle of deep ruby organic pomegranate molasses with fresh pomegranate seeds",
    badge: null,
    rating: "4.7",
    stock: 60,
    featured: false,
    sort: 8,
  },
];

export const fallbackReviews: ReviewData[] = [
  {
    id: 1,
    name: "Layla Haddad",
    location: "Austin, TX",
    rating: 5,
    text: "The honey tastes like the meadow my grandfather kept bees in. I've ordered six jars this year — every single one arrives perfectly packed, with a handwritten note. This is what shopping should feel like.",
    sort: 1,
  },
  {
    id: 2,
    name: "Omar Farouki",
    location: "Chicago, IL",
    rating: 5,
    text: "As a chef, I am ruthless about sourcing. Al Amanah's olive oil and za'atar have replaced suppliers I've used for a decade. The traceability certificates sealed it for me.",
    sort: 2,
  },
  {
    id: 3,
    name: "Priya Nair",
    location: "Seattle, WA",
    rating: 5,
    text: "Ordered Tuesday night, box on my doorstep Thursday morning, everything still cool. The dates are obscenely good — soft as caramel. My kids now ask for 'nature candy' instead of sweets.",
    sort: 3,
  },
  {
    id: 4,
    name: "Yusuf Ali",
    location: "Houston, TX",
    rating: 4,
    text: "Subscribed for monthly pantry boxes. Quality has been consistently excellent for eight months. One late delivery in a heatwave, and they refunded it before I even noticed. Trust earned.",
    sort: 4,
  },
  {
    id: 5,
    name: "Hannah Weiss",
    location: "Portland, OR",
    rating: 5,
    text: "You can taste the difference between food made for shelves and food made for people. The almond butter is a single ingredient and somehow the best thing in my kitchen.",
    sort: 5,
  },
  {
    id: 6,
    name: "Karim Sayed",
    location: "New York, NY",
    rating: 5,
    text: "Gifted a harvest box to my mother. She called me in tears — said the pomegranate molasses tasted exactly like her childhood in Aleppo. Some things money usually can't buy.",
    sort: 6,
  },
];

export const fallbackFaqs: FaqData[] = [
  {
    id: 1,
    question: "Is everything on Al Amanah Cart certified organic?",
    answer:
      "Yes. Every product we list is certified organic by a recognised body (USDA Organic or equivalent), and we publish the certificate and lab report for each batch on request. Around 20% of our range goes further — biodynamic or regeneratively farmed. If we can't trace a product to the field it came from, we simply don't sell it.",
    category: "Sourcing",
    sort: 1,
  },
  {
    id: 2,
    question: "Where do your products come from?",
    answer:
      "We work directly with 60+ small farms and producers — olive estates in the Mediterranean, date orchards, mountain herb gatherers, and local apiaries. Each product page names the farm or cooperative, and we visit every partner at least once a year before renewing their contract.",
    category: "Sourcing",
    sort: 2,
  },
  {
    id: 3,
    question: "How fast is delivery, and how do you pack fresh goods?",
    answer:
      "Orders placed before 2pm ship the same day and arrive within 1–3 business days. We pack with recycled paper insulation and compostable liners; chilled items travel with plant-based gel packs. Shipping is free on orders over $49, otherwise a flat $5.90.",
    category: "Shipping",
    sort: 3,
  },
  {
    id: 4,
    question: "What if something arrives damaged or I'm not happy?",
    answer:
      "Our Amanah Promise: if anything arrives damaged, melted, or simply doesn't delight you, tell us within 30 days and we refund or replace it immediately — no returns label, no interrogation, no fine print. Trust works both ways.",
    category: "Returns",
    sort: 4,
  },
  {
    id: 5,
    question: "Are your products halal?",
    answer:
      "Yes — the entire range is naturally halal, and products where certification matters (pantry staples, sweets) carry halal certification alongside organic. 'Amanah' means the trust placed in us, and we take that literally in everything we source.",
    category: "Sourcing",
    sort: 5,
  },
  {
    id: 6,
    question: "Can I set up a recurring delivery or subscription?",
    answer:
      "Absolutely. Any product can become a subscription at 10% off, delivered every 2, 4, or 8 weeks. You can pause, swap items, or cancel in one click from your account — no lock-ins, ever.",
    category: "Orders",
    sort: 6,
  },
];
