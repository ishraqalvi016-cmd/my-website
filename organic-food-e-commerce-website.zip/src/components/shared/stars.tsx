// ---------------------------------------------------------------------------
// Star rating display with fractional fill (e.g. 4.7 → 94% width overlay).
// Server-safe, purely presentational.
// ---------------------------------------------------------------------------
import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function Stars({
  rating,
  className,
  starClass = "size-4",
}: {
  rating: number;
  className?: string;
  starClass?: string;
}) {
  const pct = Math.max(0, Math.min(100, (rating / 5) * 100));
  return (
    <span
      className={cn("relative inline-flex shrink-0", className)}
      role="img"
      aria-label={`Rated ${rating} out of 5 stars`}
    >
      {/* Outline track */}
      <span className="flex gap-0.5 text-forest-300">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star key={i} className={starClass} aria-hidden />
        ))}
      </span>
      {/* Filled overlay, clipped to the rating percentage */}
      <span
        className="absolute inset-0 flex gap-0.5 overflow-hidden text-honey-400"
        style={{ width: `${pct}%` }}
      >
        {Array.from({ length: 5 }).map((_, i) => (
          <Star key={i} className={cn(starClass, "shrink-0 fill-current")} aria-hidden />
        ))}
      </span>
    </span>
  );
}
