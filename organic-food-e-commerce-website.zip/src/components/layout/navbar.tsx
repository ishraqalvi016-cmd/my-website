"use client";

// ---------------------------------------------------------------------------
// Sticky navbar: transparent over the hero, frosted glass once scrolled.
// Includes the cart trigger (live badge) and an animated mobile menu.
// ---------------------------------------------------------------------------
import { AnimatePresence, motion } from "framer-motion";
import { Leaf, Menu, ShoppingBasket, X } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useCart } from "@/components/cart/cart-context";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/products", label: "Shop" },
  { href: "/about", label: "Our Story" },
  { href: "/#reviews", label: "Reviews" },
  { href: "/#faq", label: "FAQ" },
  { href: "/contact", label: "Contact" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { count, openCart } = useCart();
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the mobile menu on navigation.
  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled
          ? "border-b border-forest-900/10 bg-cream-50/85 shadow-sm shadow-forest-950/5 backdrop-blur-xl"
          : "bg-transparent",
      )}
    >
      <nav
        aria-label="Main navigation"
        className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-4 md:px-8"
      >
        {/* Wordmark */}
        <Link href="/" className="focus-ring group flex items-center gap-2.5 rounded-full">
          <span className="flex size-10 items-center justify-center rounded-full bg-forest-800 text-cream-50 transition-transform duration-500 group-hover:rotate-[20deg]">
            <Leaf className="size-5" aria-hidden />
          </span>
          <span className="leading-none">
            <span className="block font-display text-lg font-semibold tracking-tight text-forest-950">
              Al Amanah
            </span>
            <span className="block text-[10px] font-bold tracking-[0.32em] text-clay-600 uppercase">
              Organic Cart
            </span>
          </span>
        </Link>

        {/* Desktop links */}
        <ul className="hidden items-center gap-1 lg:flex">
          {LINKS.map((link) => {
            const active =
              link.href === pathname ||
              (link.href !== "/" && !link.href.includes("#") && pathname.startsWith(link.href));
            return (
              <li key={link.label}>
                <Link
                  href={link.href}
                  className={cn(
                    "focus-ring rounded-full px-4 py-2 text-sm font-medium transition-colors",
                    active
                      ? "bg-forest-800 text-cream-50"
                      : "text-forest-800 hover:bg-forest-800/8 hover:text-forest-950",
                  )}
                >
                  {link.label}
                </Link>
              </li>
            );
          })}
        </ul>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={openCart}
            aria-label={`Open cart, ${count} item${count === 1 ? "" : "s"}`}
            className="focus-ring relative flex items-center gap-2 rounded-full bg-forest-800 px-4 py-2.5 text-sm font-semibold text-cream-50 transition hover:bg-forest-900"
          >
            <ShoppingBasket className="size-4.5" aria-hidden />
            <span className="hidden sm:inline">Basket</span>
            <AnimatePresence>
              {count > 0 && (
                <motion.span
                  key="badge"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  className="absolute -top-1.5 -right-1.5 flex size-5 items-center justify-center rounded-full bg-clay-500 text-[11px] font-bold text-cream-50 ring-2 ring-cream-50"
                >
                  {count}
                </motion.span>
              )}
            </AnimatePresence>
          </button>

          <button
            onClick={() => setMenuOpen((v) => !v)}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            className="focus-ring rounded-full p-2.5 text-forest-900 transition hover:bg-forest-800/8 lg:hidden"
          >
            {menuOpen ? <X className="size-5" aria-hidden /> : <Menu className="size-5" aria-hidden />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            key="mobile-nav"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden border-b border-forest-900/10 bg-cream-50/95 backdrop-blur-xl lg:hidden"
            aria-label="Mobile navigation"
          >
            <ul className="space-y-1 px-5 py-4">
              {LINKS.map((link, i) => (
                <motion.li
                  key={link.label}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i }}
                >
                  <Link
                    href={link.href}
                    onClick={() => setMenuOpen(false)}
                    className="focus-ring block rounded-2xl px-4 py-3 font-display text-2xl font-medium text-forest-900 transition hover:bg-forest-800/6"
                  >
                    {link.label}
                  </Link>
                </motion.li>
              ))}
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
