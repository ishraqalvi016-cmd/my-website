// ---------------------------------------------------------------------------
// Featured products showcase on the home page (server component — data passed
// in from the page). Cards themselves are client islands for add-to-cart.
// ---------------------------------------------------------------------------
import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { ProductCard } from "@/components/products/product-card";
import { SectionHeading } from "@/components/shared/section-heading";
import type { ProductData } from "@/lib/fallback-data";

export function FeaturedProducts({ products }: { products: ProductData[] }) {
  return (
    <section className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28" aria-label="Featured products">
      <SectionHeading
        kicker="This season's harvest"
        title={
          <>
            Staples worth <em className="text-clay-600 italic">slowing down</em> for
          </>
        }
        description="Small batches, honest labels, flavours that taste like somewhere. These are the jars and boxes our customers reorder most."
      />

      <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {products.slice(0, 4).map((product, i) => (
          <ProductCard key={product.id} product={product} index={i} />
        ))}
      </div>

      <div className="mt-12 text-center">
        <Link
          href="/products"
          className="focus-ring group inline-flex items-center gap-2.5 rounded-full border border-forest-900/20 bg-cream-50 px-7 py-4 text-sm font-bold text-forest-900 transition hover:border-forest-800 hover:bg-forest-800 hover:text-cream-50"
        >
          Browse the full pantry
          <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden />
        </Link>
      </div>
    </section>
  );
}
