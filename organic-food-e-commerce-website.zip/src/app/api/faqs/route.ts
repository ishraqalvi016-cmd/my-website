// ---------------------------------------------------------------------------
// GET /api/faqs — frequently asked questions.
// ---------------------------------------------------------------------------
import { NextResponse } from "next/server";
import { getFaqs } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  const faqs = await getFaqs();
  return NextResponse.json({ faqs });
}
