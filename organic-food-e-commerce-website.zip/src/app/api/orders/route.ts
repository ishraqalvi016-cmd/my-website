// ---------------------------------------------------------------------------
// POST /api/orders — places a lightweight order from the cart drawer.
// Prices are always re-derived server-side from the catalog (never trusted
// from the client). Returns an order reference for confirmation.
// ---------------------------------------------------------------------------
import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, type OrderItem } from "@/db/schema";
import { getProducts } from "@/lib/data";
import { orderNumber } from "@/lib/utils";

const FREE_SHIPPING_AT = 49;
const FLAT_SHIPPING = 5.9;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type IncomingItem = { productId?: unknown; quantity?: unknown };

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      customerName?: unknown;
      customerEmail?: unknown;
      items?: IncomingItem[];
    };

    const customerName = String(body.customerName ?? "").trim();
    const customerEmail = String(body.customerEmail ?? "").trim();

    if (!customerName || !EMAIL_RE.test(customerEmail)) {
      return NextResponse.json(
        { error: "Name and a valid email are required." },
        { status: 400 },
      );
    }
    if (!Array.isArray(body.items) || body.items.length === 0) {
      return NextResponse.json({ error: "Your basket is empty." }, { status: 400 });
    }

    // Re-price every line against the authoritative catalog.
    const catalog = await getProducts();
    const items: OrderItem[] = [];
    let subtotal = 0;

    for (const raw of body.items.slice(0, 50)) {
      const productId = Number(raw.productId);
      const quantity = Math.max(0, Math.min(99, Math.floor(Number(raw.quantity))));
      const product = catalog.find((p) => p.id === productId);
      if (!product || quantity === 0) continue;
      items.push({
        productId: product.id,
        name: product.name,
        price: product.price,
        unit: product.unit,
        quantity,
      });
      subtotal += Number(product.price) * quantity;
    }

    if (items.length === 0) {
      return NextResponse.json(
        { error: "None of those products could be found." },
        { status: 400 },
      );
    }

    const shipping = subtotal >= FREE_SHIPPING_AT ? 0 : FLAT_SHIPPING;
    const total = subtotal + shipping;
    const ref = orderNumber();

    // Persist the order; if the database is briefly unreachable the customer
    // still gets a confirmation rather than a dead end.
    try {
      await db.insert(orders).values({
        orderNumber: ref,
        customerName,
        customerEmail,
        items,
        total: total.toFixed(2),
      });
    } catch (persistErr) {
      console.error("[api/orders] persistence failed:", persistErr);
    }

    return NextResponse.json(
      { ok: true, orderNumber: ref, total: total.toFixed(2) },
      { status: 201 },
    );
  } catch (err) {
    console.error("[api/orders] failed:", err);
    return NextResponse.json(
      { error: "Could not place your order right now." },
      { status: 500 },
    );
  }
}
