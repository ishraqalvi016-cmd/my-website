// ---------------------------------------------------------------------------
// XML sitemap for search engines (served at /sitemap.xml).
// ---------------------------------------------------------------------------
import type { MetadataRoute } from "next";

const BASE = "https://alamanahcart.com";

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = ["", "/products", "/about", "/contact"];
  return routes.map((path) => ({
    url: `${BASE}${path}`,
    lastModified: new Date(),
    changeFrequency: path === "" ? "weekly" : "monthly",
    priority: path === "" ? 1 : 0.8,
  }));
}
