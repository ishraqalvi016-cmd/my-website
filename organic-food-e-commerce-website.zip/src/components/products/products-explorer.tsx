"use client";

// ---------------------------------------------------------------------------
// Interactive shop explorer: category chips, live search and sorting over the
// catalog passed down from the server page.
// ---------------------------------------------------------------------------
import { ArrowUpDown, PackageSearch, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { ProductCard } from "@/components/products/product-card";
import type { ProductData } from "@/lib/fallback-data";
import { cn } from "@/lib/utils";

type SortKey = "featured" | "price-asc" | "price-desc" | "rating";

const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: "featured", label: "Featured" },
  { value: "price-asc", label: "Price: low → high" },
  { value: "price-desc", label: "Price: high → low" },
  { value: "rating", label: "Top rated" },
];

export function ProductsExplorer({
  products,
  initialCategory = "All",
}: {
  products: ProductData[];
  initialCategory?: string;
}) {
  const [category, setCategory] = useState(initialCategory);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortKey>("featured");

  // Unique category list, preserving catalog order.
  const categories = useMemo(
    () => ["All", ...Array.from(new Set(products.map((p) => p.category)))],
    [products],
  );

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = products.filter((p) => {
      const inCategory = category === "All" || p.category === category;
      const matches =
        !q ||
        `${p.name} ${p.tagline} ${p.description} ${p.category}`
          .toLowerCase()
          .includes(q);
      return inCategory && matches;
    });
    switch (sort) {
      case "price-asc":
        list = [...list].sort((a, b) => Number(a.price) - Number(b.price));
        break;
      case "price-desc":
        list = [...list].sort((a, b) => Number(b.price) - Number(a.price));
        break;
      case "rating":
        list = [...list].sort((a, b) => Number(b.rating) - Number(a.rating));
        break;
      default:
        list = [...list].sort((a, b) => a.sort - b.sort);
    }
    return list;
  }, [products, category, query, sort]);

  return (
    <div>
      {/* Controls */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        {/* Category chips — horizontally scrollable on mobile */}
        <div
          className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 lg:mx-0 lg:flex-wrap lg:px-0"
          role="tablist"
          aria-label="Filter by category"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              role="tab"
              aria-selected={category === cat}
              onClick={() => setCategory(cat)}
              className={cn(
                "focus-ring shrink-0 rounded-full border px-4.5 py-2.5 text-sm font-semibold whitespace-nowrap transition-all duration-300",
                category === cat
                  ? "border-forest-800 bg-forest-800 text-cream-50 shadow-md shadow-forest-900/20"
                  : "border-forest-900/15 bg-cream-50 text-forest-800 hover:border-forest-800/40",
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search + sort */}
        <div className="flex gap-2">
          <label className="focus-within:ring-clay-400/60 relative flex flex-1 items-center rounded-full border border-forest-900/15 bg-cream-50 px-4 transition focus-within:ring-3 lg:w-64">
            <Search className="size-4 text-forest-500" aria-hidden />
            <span className="sr-only">Search products</span>
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search honey, dates, tea…"
              className="w-full bg-transparent px-2.5 py-2.5 text-sm text-forest-950 placeholder:text-forest-400 focus:outline-none"
            />
          </label>
          <label className="relative flex items-center rounded-full border border-forest-900/15 bg-cream-50 px-4 transition focus-within:ring-3 focus-within:ring-clay-400/60">
            <ArrowUpDown className="size-4 shrink-0 text-forest-500" aria-hidden />
            <span className="sr-only">Sort products</span>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
              className="cursor-pointer appearance-none bg-transparent py-2.5 pr-6 pl-2.5 text-sm font-medium text-forest-900 focus:outline-none"
            >
              {SORT_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
            <span aria-hidden className="pointer-events-none absolute right-4 text-forest-500">
              ▾
            </span>
          </label>
        </div>
      </div>

      {/* Result count */}
      <p className="mt-6 text-sm font-medium text-forest-600" aria-live="polite">
        Showing <span className="font-bold text-forest-950">{visible.length}</span>{" "}
        of {products.length} products
        {category !== "All" && (
          <>
            {" "}
            in <span className="font-bold text-clay-600">{category}</span>
          </>
        )}
      </p>

      {/* Grid / empty state */}
      {visible.length > 0 ? (
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {visible.map((product, i) => (
            <ProductCard key={product.id} product={product} index={i} />
          ))}
        </div>
      ) : (
        <div className="mt-6 flex flex-col items-center gap-4 rounded-[32px] border border-dashed border-forest-900/20 bg-cream-50/60 px-6 py-20 text-center">
          <PackageSearch className="size-10 text-forest-400" aria-hidden />
          <p className="font-display text-2xl font-semibold text-forest-950">
            Nothing grows here yet
          </p>
          <p className="max-w-sm text-sm text-forest-600">
            No products match “{query}”. Try a different search or browse the
            whole pantry instead.
          </p>
          <button
            onClick={() => {
              setQuery("");
              setCategory("All");
            }}
            className="focus-ring rounded-full bg-forest-800 px-6 py-3 text-sm font-bold text-cream-50 transition hover:bg-forest-900"
          >
            Clear filters
          </button>
        </div>
      )}
    </div>
  );
}
