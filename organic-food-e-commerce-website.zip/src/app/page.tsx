// ---------------------------------------------------------------------------
// Home page: hero → marquee → featured products → values → story → reviews →
// FAQ → CTA. Data comes from PostgreSQL (with bundled fallbacks).
// ---------------------------------------------------------------------------
import type { Metadata } from "next";
import { CtaBand } from "@/components/home/cta-band";
import { FaqSection } from "@/components/home/faq-section";
import { FeaturedProducts } from "@/components/home/featured-products";
import { Hero } from "@/components/home/hero";
import { ReviewsSection } from "@/components/home/reviews-section";
import { StoryStrip } from "@/components/home/story-strip";
import { Values } from "@/components/home/values";
import { Marquee } from "@/components/shared/marquee";
import { getFaqs, getFeaturedProducts, getReviews } from "@/lib/data";

// Render per-request so the catalog is always fresh from the database.
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Al Amanah Cart — Honest Organic Food, Farm to Door",
  description:
    "Shop certified-organic honey, olive oil, dates, teas and pantry staples sourced from 60+ small farms. Free shipping over $49 · 30-day Amanah Promise.",
  alternates: { canonical: "/" },
};

const MARQUEE_ITEMS = [
  "100% Certified Organic",
  "Farm Direct — 60+ Partners",
  "Free Shipping Over $49",
  "30-Day Amanah Promise",
  "Compostable Packaging",
  "Harvest to Door in 48h",
];

export default async function HomePage() {
  // Fetch in parallel; data layer falls back to bundled content if needed.
  const [products, reviews, faqs] = await Promise.all([
    getFeaturedProducts(),
    getReviews(),
    getFaqs(),
  ]);

  return (
    <>
      <Hero />
      <Marquee items={MARQUEE_ITEMS} />
      <FeaturedProducts products={products} />
      <Values />
      <StoryStrip />
      <ReviewsSection reviews={reviews} />
      <FaqSection faqs={faqs} />
      <CtaBand />
    </>
  );
}
