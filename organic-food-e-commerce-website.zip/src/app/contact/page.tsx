// ---------------------------------------------------------------------------
// Contact page: info panel (email, phone, address, socials), message form and
// an interactive OpenStreetMap embed.
// ---------------------------------------------------------------------------
import type { Metadata } from "next";
import { Clock, Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { ContactForm } from "@/components/contact/contact-form";
import { Reveal } from "@/components/shared/reveal";
import {
  FacebookIcon,
  InstagramIcon,
  XSocialIcon,
  YoutubeIcon,
} from "@/components/shared/social-icons";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Questions about an order, wholesale or sourcing? Email hello@alamanahcart.com, call +1 (512) 555-0134, or visit us at 2410 Harvest Lane, Austin TX.",
  alternates: { canonical: "/contact" },
  openGraph: {
    title: "Contact · Al Amanah Cart",
    description:
      "Talk to a real human: email, phone, or visit our Austin storefront. We reply within one business day.",
  },
};

const SOCIALS = [
  { href: "https://instagram.com/alamanahcart", label: "Instagram", Icon: InstagramIcon },
  { href: "https://facebook.com/alamanahcart", label: "Facebook", Icon: FacebookIcon },
  { href: "https://x.com/alamanahcart", label: "X (Twitter)", Icon: XSocialIcon },
  { href: "https://youtube.com/@alamanahcart", label: "YouTube", Icon: YoutubeIcon },
];

export default function ContactPage() {
  return (
    <>
      {/* Header */}
      <section className="grain relative overflow-hidden pt-32 pb-12 md:pt-40 md:pb-16">
        <div
          aria-hidden
          className="absolute -top-32 -left-24 size-[26rem] rounded-full bg-forest-200/50 blur-3xl"
        />
        <div className="relative z-[2] mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <p className="inline-flex items-center gap-2 rounded-full border border-forest-900/15 bg-cream-50/80 px-4 py-2 text-[11px] font-bold tracking-[0.24em] text-forest-800 uppercase">
              <MessageCircle className="size-3.5 text-clay-500" aria-hidden />
              Contact · replies within 1 business day
            </p>
            <h1 className="mt-6 max-w-3xl font-display text-5xl leading-[1.02] font-semibold tracking-tight text-balance text-forest-950 md:text-7xl">
              Talk to a <em className="text-clay-600 italic">human</em>, not a ticket queue.
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-forest-700">
              Order help, wholesale enquiries, farm partnerships or just recipe
              advice — write, call, or drop by. We genuinely love mail.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Info + form */}
      <section className="mx-auto max-w-7xl px-5 pb-20 md:px-8" aria-label="Contact details and form">
        <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          {/* Info panel */}
          <Reveal>
            <div className="grain texture-dots relative flex h-full flex-col overflow-hidden rounded-[32px] bg-forest-950 p-7 md:p-9">
              <div className="relative z-[2]">
                <h2 className="font-display text-2xl font-semibold text-cream-50">
                  Reach us directly
                </h2>
                <ul className="mt-7 space-y-6">
                  <li>
                    <a
                      href="mailto:hello@alamanahcart.com"
                      className="focus-ring group flex items-start gap-4 rounded-2xl"
                    >
                      <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-cream-100/10 text-honey-300 transition group-hover:bg-clay-500 group-hover:text-cream-50">
                        <Mail className="size-5" aria-hidden />
                      </span>
                      <span>
                        <span className="block text-xs font-bold tracking-[0.2em] text-cream-100/50 uppercase">
                          Email
                        </span>
                        <span className="mt-1 block font-medium text-cream-50 group-hover:underline">
                          hello@alamanahcart.com
                        </span>
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="tel:+15125550134" className="focus-ring group flex items-start gap-4 rounded-2xl">
                      <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-cream-100/10 text-honey-300 transition group-hover:bg-clay-500 group-hover:text-cream-50">
                        <Phone className="size-5" aria-hidden />
                      </span>
                      <span>
                        <span className="block text-xs font-bold tracking-[0.2em] text-cream-100/50 uppercase">
                          Phone
                        </span>
                        <span className="mt-1 block font-medium text-cream-50 group-hover:underline">
                          +1 (512) 555-0134
                        </span>
                      </span>
                    </a>
                  </li>
                  <li className="flex items-start gap-4">
                    <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-cream-100/10 text-honey-300">
                      <MapPin className="size-5" aria-hidden />
                    </span>
                    <span>
                      <span className="block text-xs font-bold tracking-[0.2em] text-cream-100/50 uppercase">
                        Storefront
                      </span>
                      <span className="mt-1 block leading-relaxed text-cream-100/85">
                        2410 Harvest Lane, Suite 12
                        <br />
                        Austin, TX 78704
                      </span>
                    </span>
                  </li>
                  <li className="flex items-start gap-4">
                    <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-cream-100/10 text-honey-300">
                      <Clock className="size-5" aria-hidden />
                    </span>
                    <span>
                      <span className="block text-xs font-bold tracking-[0.2em] text-cream-100/50 uppercase">
                        Hours
                      </span>
                      <span className="mt-1 block leading-relaxed text-cream-100/85">
                        Mon–Sat · 9:00 – 18:00 CT
                        <br />
                        Sundays · closed (we rest)
                      </span>
                    </span>
                  </li>
                </ul>

                {/* Socials */}
                <div className="mt-9 border-t border-cream-100/10 pt-7">
                  <p className="text-xs font-bold tracking-[0.2em] text-cream-100/50 uppercase">
                    Follow the harvest
                  </p>
                  <div className="mt-4 flex gap-2.5">
                    {SOCIALS.map(({ href, label, Icon }) => (
                      <a
                        key={label}
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={`Al Amanah Cart on ${label}`}
                        className="focus-ring flex size-11 items-center justify-center rounded-full border border-cream-100/15 text-cream-100/80 transition hover:border-honey-300 hover:bg-honey-300 hover:text-forest-950"
                      >
                        <Icon className="size-4.5" aria-hidden />
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

          {/* Form */}
          <Reveal delay={0.12}>
            <ContactForm />
          </Reveal>
        </div>
      </section>

      {/* Map */}
      <section className="mx-auto max-w-7xl px-5 pb-24 md:px-8" aria-label="Find us on the map">
        <Reveal>
          <div className="overflow-hidden rounded-[32px] border border-forest-900/10 shadow-lg shadow-forest-950/8">
            <div className="flex flex-wrap items-center justify-between gap-3 bg-cream-50 px-6 py-4">
              <p className="flex items-center gap-2.5 text-sm font-bold text-forest-950">
                <MapPin className="size-4 text-clay-500" aria-hidden />
                Al Amanah Cart storefront — South Congress, Austin
              </p>
              <a
                href="https://www.openstreetmap.org/?mlat=30.2520&mlon=-97.7490#map=15/30.2520/-97.7490"
                target="_blank"
                rel="noopener noreferrer"
                className="focus-ring link-underline rounded text-sm font-semibold text-clay-600"
              >
                Open larger map →
              </a>
            </div>
            <iframe
              title="Map showing the Al Amanah Cart storefront in Austin, Texas"
              src="https://www.openstreetmap.org/export/embed.html?bbox=-97.7780%2C30.2360%2C-97.7160%2C30.2700&layer=mapnik&marker=30.2520%2C-97.7490"
              className="h-[420px] w-full border-0 grayscale-[35%] contrast-[1.02] sepia-[0.12]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </div>
        </Reveal>
      </section>
    </>
  );
}
