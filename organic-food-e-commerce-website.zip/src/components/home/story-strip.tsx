// ---------------------------------------------------------------------------
// Story teaser split panel — image left, narrative right, leads to /about.
// ---------------------------------------------------------------------------
import { ArrowRight, Quote, Sprout } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { Reveal } from "@/components/shared/reveal";

export function StoryStrip() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28" aria-label="Our story preview">
      <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
        {/* Image side */}
        <Reveal className="relative">
          <div
            aria-hidden
            className="absolute -top-6 -left-6 size-32 animate-spin-slow rounded-full border border-dashed border-forest-500/40"
          />
          <div className="relative aspect-[4/3] overflow-hidden rounded-[36px] shadow-2xl shadow-forest-950/15">
            <Image
              src="/images/about.jpg"
              alt="A farmer's hands cupping rich soil with young organic seedlings at golden hour"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
          {/* Floating stat card */}
          <div className="absolute -right-3 -bottom-6 animate-float rounded-2xl border border-forest-900/10 bg-cream-50 px-5 py-4 shadow-xl shadow-forest-950/10 md:-right-6">
            <p className="font-display text-3xl font-bold text-forest-900">60+</p>
            <p className="text-xs font-semibold tracking-wide text-forest-600 uppercase">
              Partner farms
            </p>
          </div>
        </Reveal>

        {/* Copy side */}
        <div>
          <Reveal>
            <p className="flex items-center gap-3 text-xs font-bold tracking-[0.3em] text-clay-600 uppercase">
              <span aria-hidden className="h-px w-8 bg-clay-600/50" />
              Our roots
            </p>
            <h2 className="mt-4 font-display text-4xl leading-[1.06] font-semibold tracking-tight text-balance text-forest-950 md:text-5xl">
              It began at <em className="text-clay-600 italic">grandmother&apos;s</em> table
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="relative mt-6 rounded-3xl border border-forest-900/10 bg-cream-50 p-6">
              <Quote className="absolute -top-4 left-6 size-8 rounded-full bg-forest-800 p-1.5 text-cream-50" aria-hidden />
              <p className="font-display text-lg leading-relaxed text-forest-900 italic">
                &ldquo;If you cannot trace it to a field, it does not belong on
                your table.&rdquo;
              </p>
              <p className="mt-3 text-sm font-semibold text-forest-600">
                — The words we still source by, every single season.
              </p>
            </div>
            <p className="mt-6 leading-relaxed text-forest-700">
              Al Amanah means <em>&ldquo;the trust&rdquo;</em> — the thing placed in
              your hands that you must guard. We started in 2016 with one honey
              cooperative and a promise: food you can trace, from farmers you
              can name. Nine years later the family has grown, but the promise
              hasn&apos;t moved an inch.
            </p>
            <Link
              href="/about"
              className="focus-ring group mt-8 inline-flex items-center gap-2.5 rounded-full bg-forest-800 px-7 py-4 text-sm font-bold text-cream-50 transition hover:bg-forest-900"
            >
              <Sprout className="size-4" aria-hidden />
              Read our full story
              <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden />
            </Link>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
