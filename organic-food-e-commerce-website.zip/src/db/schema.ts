// ---------------------------------------------------------------------------
// Al Amanah Cart — database schema (Drizzle ORM / PostgreSQL)
// Tables: products, reviews, faqs, contact_messages, orders
// ---------------------------------------------------------------------------
import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";

/** Organic products sold in the shop. */
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  tagline: text("tagline").notNull().default(""),
  description: text("description").notNull().default(""),
  category: text("category").notNull().default("pantry"),
  /** Price in USD stored as numeric string to avoid float drift. */
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  unit: text("unit").notNull().default("each"),
  image: text("image").notNull().default(""),
  alt: text("alt").notNull().default(""),
  badge: text("badge"),
  rating: numeric("rating", { precision: 2, scale: 1 }).notNull().default("5"),
  stock: integer("stock").notNull().default(50),
  featured: boolean("featured").notNull().default(false),
  sort: integer("sort").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Customer testimonials shown on the home & about pages. */
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull().default(""),
  rating: integer("rating").notNull().default(5),
  text: text("text").notNull(),
  sort: integer("sort").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Frequently asked questions, grouped by category. */
export const faqs = pgTable("faqs", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  category: text("category").notNull().default("General"),
  sort: integer("sort").notNull().default(0),
});

/** Messages submitted through the contact form. */
export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull().default(""),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Line item shape stored inside an order. */
export type OrderItem = {
  productId: number;
  name: string;
  price: string;
  unit: string;
  quantity: number;
};

/** Orders placed from the cart drawer. */
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  items: jsonb("items").$type<OrderItem[]>().notNull(),
  total: numeric("total", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("received"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
