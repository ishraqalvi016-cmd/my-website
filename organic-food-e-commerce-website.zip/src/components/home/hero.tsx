"use client";

// ---------------------------------------------------------------------------
// Hero: editorial serif headline, parallax arch image, floating trust badges.
// ---------------------------------------------------------------------------
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, Leaf, ShieldCheck, Truck } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useRef } from "react";
import { Stars } from "@/components/shared/stars";

const EASE = [0.22, 1, 0.36, 1] as const;

export function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  // Gentle parallax: the arched image drifts down as the hero scrolls away.
  const imageY = useTransform(scrollYProgress, [0, 1], ["0%", "12%"]);

  return (
    <section
      ref={ref}
      className="grain relative overflow-hidden pt-32 pb-16 md:pt-40 md:pb-24"
      aria-label="Introduction"
    >
      {/* Ambient blobs */}
      <div
        aria-hidden
        className="absolute -top-40 -left-40 size-[34rem] rounded-full bg-forest-200/40 blur-3xl"
      />
      <div
        aria-hidden
        className="absolute top-1/3 -right-48 size-[30rem] rounded-full bg-honey-300/30 blur-3xl"
      />

      <div className="relative z-[2] mx-auto grid max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-8">
        {/* Copy */}
        <div>
          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: EASE }}
            className="inline-flex items-center gap-2 rounded-full border border-forest-900/15 bg-cream-50/80 px-4 py-2 text-[11px] font-bold tracking-[0.24em] text-forest-800 uppercase backdrop-blur"
          >
            <Leaf className="size-3.5 text-forest-500" aria-hidden />
            Certified organic · farm direct · est. 2016
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 32, filter: "blur(8px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ duration: 1, delay: 0.1, ease: EASE }}
            className="mt-6 font-display text-[2.9rem] leading-[1.02] font-semibold tracking-tight text-balance text-forest-950 sm:text-6xl md:text-7xl"
          >
            Honest food,
            <br />
            from the <em className="text-clay-600 italic">earth</em>
            <br />
            to your table.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.25, ease: EASE }}
            className="mt-6 max-w-xl text-lg leading-relaxed text-forest-700"
          >
            We partner with 60+ small farms to bring you honey, olive oil, dates
            and pantry staples that are traceable to the field — and
            unforgettable at the table.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.38, ease: EASE }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <Link
              href="/products"
              className="focus-ring group flex items-center gap-2.5 rounded-full bg-forest-800 px-7 py-4 text-sm font-bold text-cream-50 transition-all hover:bg-forest-900 hover:shadow-lg hover:shadow-forest-900/25"
            >
              Shop the harvest
              <ArrowRight
                className="size-4 transition-transform duration-300 group-hover:translate-x-1"
                aria-hidden
              />
            </Link>
            <Link
              href="/about"
              className="focus-ring rounded-full border border-forest-900/20 bg-cream-50/60 px-7 py-4 text-sm font-bold text-forest-900 backdrop-blur transition hover:border-forest-800 hover:bg-cream-50"
            >
              Our story
            </Link>
          </motion.div>

          {/* Social proof row */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.55 }}
            className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-4"
          >
            <div className="flex items-center gap-3">
              <Stars rating={4.9} starClass="size-4" />
              <p className="text-sm text-forest-700">
                <span className="font-bold text-forest-950">4.9</span> · 2,300+
                verified reviews
              </p>
            </div>
            <div className="flex items-center gap-2 text-sm text-forest-700">
              <Truck className="size-4 text-clay-600" aria-hidden />
              Free shipping over $49
            </div>
          </motion.div>
        </div>

        {/* Visual: arched image with floating badges */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.2, ease: EASE }}
          className="relative mx-auto w-full max-w-md lg:max-w-none"
        >
          {/* Decorative slow-spinning dashed ring */}
          <div
            aria-hidden
            className="absolute -top-8 -right-4 size-40 animate-spin-slow rounded-full border border-dashed border-clay-500/50 md:size-52"
          />
          <div
            aria-hidden
            className="absolute -bottom-10 -left-8 size-44 rounded-full bg-honey-300/40 blur-2xl"
          />

          <motion.div
            style={{ y: imageY }}
            className="relative aspect-[4/5] overflow-hidden rounded-t-[999px] rounded-b-[36px] border-[10px] border-cream-50 shadow-2xl shadow-forest-950/20"
          >
            <Image
              src="/images/hero.jpg"
              alt="A wicker harvest basket overflowing with fresh organic vegetables, greens and honey on cream linen"
              fill
              priority
              sizes="(max-width: 1024px) 90vw, 45vw"
              className="object-cover"
            />
          </motion.div>

          {/* Badge: certified */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9, delay: 0.6, ease: EASE }}
            className="absolute top-[16%] -left-3 animate-float md:-left-10"
          >
            <div className="flex items-center gap-3 rounded-2xl border border-forest-900/10 bg-cream-50/95 px-4 py-3 shadow-lg shadow-forest-950/10 backdrop-blur">
              <span className="flex size-10 items-center justify-center rounded-full bg-forest-100 text-forest-700">
                <ShieldCheck className="size-5" aria-hidden />
              </span>
              <div>
                <p className="text-sm font-bold text-forest-950">
                  100% Certified Organic
                </p>
                <p className="text-xs text-forest-600">Every batch traceable</p>
              </div>
            </div>
          </motion.div>

          {/* Badge: delivery */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9, delay: 0.75, ease: EASE }}
            className="absolute right-0 bottom-[12%] animate-float-slow md:-right-6"
          >
            <div className="flex items-center gap-3 rounded-2xl border border-forest-900/10 bg-forest-900/95 px-4 py-3 shadow-lg shadow-forest-950/25 backdrop-blur">
              <span className="flex size-10 items-center justify-center rounded-full bg-cream-50/10 text-honey-300">
                <Truck className="size-5" aria-hidden />
              </span>
              <div>
                <p className="text-sm font-bold text-cream-50">
                  Harvest to door
                </p>
                <p className="text-xs text-cream-100/70">Within 48 hours</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
