// ---------------------------------------------------------------------------
// Products page: header band + interactive explorer fed from the database.
// ---------------------------------------------------------------------------
import type { Metadata } from "next";
import { Sprout } from "lucide-react";
import { ProductsExplorer } from "@/components/products/products-explorer";
import { Reveal } from "@/components/shared/reveal";
import { getProducts } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop Organic Pantry Staples",
  description:
    "Browse certified-organic honey, olive oil, dates, granola, teas, spices and more — each traceable to a named farm. Free shipping over $49.",
  alternates: { canonical: "/products" },
  openGraph: {
    title: "Shop Organic Pantry Staples · Al Amanah Cart",
    description:
      "Certified-organic pantry staples from 60+ small farms, delivered fresh to your door.",
  },
};

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const [{ category }, products] = await Promise.all([searchParams, getProducts()]);

  return (
    <>
      {/* Header band */}
      <section className="grain relative overflow-hidden pt-32 pb-14 md:pt-40 md:pb-16">
        <div
          aria-hidden
          className="absolute -top-32 right-0 size-[26rem] rounded-full bg-forest-200/50 blur-3xl"
        />
        <div className="relative z-[2] mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <p className="inline-flex items-center gap-2 rounded-full border border-forest-900/15 bg-cream-50/80 px-4 py-2 text-[11px] font-bold tracking-[0.24em] text-forest-800 uppercase">
              <Sprout className="size-3.5 text-forest-500" aria-hidden />
              The pantry · {products.length} honest products
            </p>
            <h1 className="mt-6 max-w-3xl font-display text-5xl leading-[1.02] font-semibold tracking-tight text-balance text-forest-950 md:text-7xl">
              Everything here was <em className="text-clay-600 italic">grown</em>,
              not manufactured.
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-forest-700">
              Small batches from farms we know by first name. Prices plain,
              labels honest, flavours unforgettable.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Explorer */}
      <section className="mx-auto max-w-7xl px-5 pb-24 md:px-8" aria-label="Product catalog">
        <ProductsExplorer products={products} initialCategory={category} />
      </section>
    </>
  );
}
