"use client";

// ---------------------------------------------------------------------------
// Contact form: posts to /api/contact with loading / success / error states.
// ---------------------------------------------------------------------------
import { motion } from "framer-motion";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { useState, type FormEvent } from "react";
import { cn } from "@/lib/utils";

type Phase = "idle" | "sending" | "sent" | "error";

const INPUT_CLASS =
  "focus-ring w-full rounded-2xl border border-forest-900/15 bg-cream-50 px-4 py-3.5 text-sm text-forest-950 placeholder:text-forest-400 transition";

export function ContactForm() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [form, setForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const set = (key: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => setForm((f) => ({ ...f, [key]: e.target.value }));

  async function submit(e: FormEvent) {
    e.preventDefault();
    setPhase("sending");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Send failed");
      setPhase("sent");
    } catch {
      setPhase("error");
    }
  }

  if (phase === "sent") {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex h-full min-h-[420px] flex-col items-center justify-center gap-4 rounded-[28px] border border-forest-900/10 bg-cream-50 p-10 text-center"
      >
        <CheckCircle2 className="size-14 text-forest-500" aria-hidden />
        <h3 className="font-display text-2xl font-semibold text-forest-950">
          Message received
        </h3>
        <p className="max-w-sm text-sm leading-relaxed text-forest-700">
          Shukran for writing — a real human (usually Amira) will reply within
          one business day.
        </p>
        <button
          onClick={() => {
            setPhase("idle");
            setForm({ name: "", email: "", subject: "", message: "" });
          }}
          className="focus-ring mt-2 rounded-full bg-forest-800 px-6 py-3 text-sm font-bold text-cream-50 transition hover:bg-forest-900"
        >
          Send another message
        </button>
      </motion.div>
    );
  }

  return (
    <form
      onSubmit={submit}
      aria-label="Contact form"
      className="rounded-[28px] border border-forest-900/10 bg-cream-50 p-6 shadow-sm shadow-forest-950/5 md:p-8"
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold tracking-[0.14em] text-forest-700 uppercase">
            Your name
          </span>
          <input
            required
            value={form.name}
            onChange={set("name")}
            placeholder="Amira Hassan"
            className={INPUT_CLASS}
            autoComplete="name"
          />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold tracking-[0.14em] text-forest-700 uppercase">
            Email
          </span>
          <input
            required
            type="email"
            value={form.email}
            onChange={set("email")}
            placeholder="you@example.com"
            className={INPUT_CLASS}
            autoComplete="email"
          />
        </label>
      </div>

      <label className="mt-4 block">
        <span className="mb-1.5 block text-xs font-bold tracking-[0.14em] text-forest-700 uppercase">
          Subject
        </span>
        <input
          required
          value={form.subject}
          onChange={set("subject")}
          placeholder="Question about an order, wholesale, press…"
          className={INPUT_CLASS}
        />
      </label>

      <label className="mt-4 block">
        <span className="mb-1.5 block text-xs font-bold tracking-[0.14em] text-forest-700 uppercase">
          Message
        </span>
        <textarea
          required
          rows={5}
          value={form.message}
          onChange={set("message")}
          placeholder="Tell us what's on your mind…"
          className={cn(INPUT_CLASS, "resize-none")}
        />
      </label>

      {phase === "error" && (
        <p className="mt-4 rounded-2xl bg-clay-100 px-4 py-3 text-sm font-medium text-clay-700" role="alert">
          Something went wrong sending your message — please try again or email
          us directly at hello@alamanahcart.com.
        </p>
      )}

      <button
        type="submit"
        disabled={phase === "sending"}
        className="focus-ring mt-6 flex w-full items-center justify-center gap-2.5 rounded-full bg-clay-500 px-6 py-4 text-sm font-bold text-cream-50 transition hover:bg-clay-600 disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
      >
        {phase === "sending" ? (
          <>
            <Loader2 className="size-4 animate-spin" aria-hidden />
            Sending…
          </>
        ) : (
          <>
            <Send className="size-4" aria-hidden />
            Send message
          </>
        )}
      </button>
    </form>
  );
}
