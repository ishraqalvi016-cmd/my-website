// ---------------------------------------------------------------------------
// Consistent editorial section header: kicker, serif headline (supports an
// italic accent span) and optional description. Server-safe.
// ---------------------------------------------------------------------------
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Reveal } from "@/components/shared/reveal";

export function SectionHeading({
  kicker,
  title,
  description,
  align = "center",
  dark = false,
}: {
  kicker: string;
  title: ReactNode;
  description?: string;
  align?: "left" | "center";
  dark?: boolean;
}) {
  return (
    <Reveal
      className={cn(
        "max-w-2xl",
        align === "center" ? "mx-auto text-center" : "text-left",
      )}
    >
      <p
        className={cn(
          "flex items-center gap-3 text-xs font-bold tracking-[0.3em] uppercase",
          align === "center" && "justify-center",
          dark ? "text-honey-300" : "text-clay-600",
        )}
      >
        <span
          aria-hidden
          className={cn(
            "h-px w-8",
            dark ? "bg-honey-300/60" : "bg-clay-600/50",
          )}
        />
        {kicker}
        <span
          aria-hidden
          className={cn(
            "h-px w-8",
            align !== "center" && "hidden",
            dark ? "bg-honey-300/60" : "bg-clay-600/50",
          )}
        />
      </p>
      <h2
        className={cn(
          "mt-4 font-display text-4xl leading-[1.06] font-semibold tracking-tight text-balance md:text-5xl",
          dark ? "text-cream-50" : "text-forest-950",
        )}
      >
        {title}
      </h2>
      {description && (
        <p
          className={cn(
            "mt-4 text-base leading-relaxed md:text-lg",
            dark ? "text-cream-100/70" : "text-forest-700",
          )}
        >
          {description}
        </p>
      )}
    </Reveal>
  );
}
