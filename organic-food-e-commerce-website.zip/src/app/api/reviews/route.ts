// ---------------------------------------------------------------------------
// GET /api/reviews — customer testimonials.
// ---------------------------------------------------------------------------
import { NextResponse } from "next/server";
import { getReviews } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  const reviews = await getReviews();
  return NextResponse.json({ reviews });
}
