"use client";

// ---------------------------------------------------------------------------
// Customer reviews: dark band with an aggregate score header and a staggered
// masonry-style card grid. Client component for scroll-triggered motion.
// ---------------------------------------------------------------------------
import { motion } from "framer-motion";
import { BadgeCheck, Quote } from "lucide-react";
import { Stars } from "@/components/shared/stars";
import type { ReviewData } from "@/lib/fallback-data";
import { initials } from "@/lib/utils";

export function ReviewsSection({ reviews }: { reviews: ReviewData[] }) {
  return (
    <section
      id="reviews"
      className="grain texture-dots relative scroll-mt-24 overflow-hidden bg-forest-950 py-20 md:py-28"
      aria-label="Customer reviews"
    >
      <div className="relative z-[2] mx-auto max-w-7xl px-5 md:px-8">
        {/* Header: aggregate rating */}
        <div className="grid items-end gap-10 lg:grid-cols-[1fr_auto]">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          >
            <p className="flex items-center gap-3 text-xs font-bold tracking-[0.3em] text-honey-300 uppercase">
              <span aria-hidden className="h-px w-8 bg-honey-300/60" />
              Word of mouth
            </p>
            <h2 className="mt-4 font-display text-4xl leading-[1.06] font-semibold tracking-tight text-balance text-cream-50 md:text-5xl">
              Loved by kitchens <em className="text-honey-300 italic">everywhere</em>
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="flex items-center gap-5 rounded-3xl border border-cream-100/15 bg-cream-100/5 px-6 py-5 backdrop-blur"
          >
            <p className="font-display text-6xl font-bold text-cream-50">4.9</p>
            <div>
              <Stars rating={4.9} starClass="size-4" />
              <p className="mt-1.5 text-sm text-cream-100/70">
                2,300+ verified reviews
              </p>
            </div>
          </motion.div>
        </div>

        {/* Cards */}
        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {reviews.map((review, i) => (
            <motion.figure
              key={review.id}
              initial={{ opacity: 0, y: 36 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{
                duration: 0.75,
                delay: (i % 3) * 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="flex flex-col rounded-[28px] bg-cream-50 p-6 shadow-lg shadow-forest-950/20"
            >
              <Quote className="size-7 text-clay-400" aria-hidden />
              <blockquote className="mt-4 flex-1 text-[15px] leading-relaxed text-forest-900">
                {review.text}
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3.5 border-t border-forest-900/8 pt-5">
                <span className="flex size-11 items-center justify-center rounded-full bg-forest-800 font-display text-sm font-bold text-cream-50">
                  {initials(review.name)}
                </span>
                <div className="flex-1">
                  <p className="flex items-center gap-1.5 text-sm font-bold text-forest-950">
                    {review.name}
                    <BadgeCheck className="size-4 text-forest-500" aria-label="Verified buyer" />
                  </p>
                  <p className="text-xs text-forest-600">{review.location}</p>
                </div>
                <Stars rating={review.rating} starClass="size-3.5" />
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
