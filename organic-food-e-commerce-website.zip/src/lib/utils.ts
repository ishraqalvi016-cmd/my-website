// ---------------------------------------------------------------------------
// Small shared utilities
// ---------------------------------------------------------------------------

/** Join class names conditionally (tiny clsx replacement). */
export function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

/** Format a numeric-string price like "14.00" | "9.50" → "$14" | "$9.50". */
export function formatPrice(value: string | number) {
  const n = typeof value === "string" ? Number(value) : value;
  if (!Number.isFinite(n)) return "$0";
  return n % 1 === 0 ? `$${n}` : `$${n.toFixed(2)}`;
}

/** Build a friendly order reference, e.g. "AAC-7F3K2Q". */
export function orderNumber() {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let tail = "";
  for (let i = 0; i < 6; i++) {
    tail += chars[Math.floor(Math.random() * chars.length)];
  }
  return `AAC-${tail}`;
}

/** Initials for review avatars ("Layla Haddad" → "LH"). */
export function initials(name: string) {
  return name
    .split(" ")
    .map((w) => w[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}
