// ---------------------------------------------------------------------------
// GET /api/products — full catalog (DB with bundled fallback).
// ---------------------------------------------------------------------------
import { NextResponse } from "next/server";
import { getProducts } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  const products = await getProducts();
  return NextResponse.json({ products });
}
