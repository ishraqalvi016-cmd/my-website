// ---------------------------------------------------------------------------
// Final call-to-action band before the footer.
// ---------------------------------------------------------------------------
import { ArrowRight, MessageCircle } from "lucide-react";
import Link from "next/link";
import { Reveal } from "@/components/shared/reveal";

export function CtaBand() {
  return (
    <section className="mx-auto max-w-7xl px-5 pb-24 md:px-8" aria-label="Get started">
      <Reveal>
        <div className="grain relative overflow-hidden rounded-[40px] bg-clay-500 px-6 py-16 text-center md:px-12 md:py-20">
          {/* Decorative circles */}
          <div aria-hidden className="absolute -top-24 -left-24 size-72 rounded-full bg-clay-400/60 blur-2xl" />
          <div aria-hidden className="absolute -right-20 -bottom-28 size-80 rounded-full bg-honey-400/40 blur-2xl" />

          <div className="relative z-[2] mx-auto max-w-2xl">
            <p className="text-xs font-bold tracking-[0.3em] text-cream-50/80 uppercase">
              Join 12,000+ happy kitchens
            </p>
            <h2 className="mt-4 font-display text-4xl leading-[1.05] font-semibold tracking-tight text-balance text-cream-50 md:text-6xl">
              Taste the difference <em className="italic">trust</em> makes.
            </h2>
            <p className="mt-5 text-base leading-relaxed text-cream-50/85 md:text-lg">
              First order delight guaranteed — if a single jar doesn&apos;t earn
              its place in your pantry, our Amanah Promise covers it.
            </p>
            <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
              <Link
                href="/products"
                className="focus-ring group flex items-center gap-2.5 rounded-full bg-cream-50 px-8 py-4 text-sm font-bold text-forest-950 transition hover:bg-cream-100 hover:shadow-xl hover:shadow-forest-950/20"
              >
                Start shopping
                <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden />
              </Link>
              <Link
                href="/contact"
                className="focus-ring flex items-center gap-2.5 rounded-full border border-cream-50/50 px-8 py-4 text-sm font-bold text-cream-50 transition hover:border-cream-50 hover:bg-cream-50/10"
              >
                <MessageCircle className="size-4" aria-hidden />
                Talk to us
              </Link>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
