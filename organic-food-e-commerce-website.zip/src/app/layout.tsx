// ---------------------------------------------------------------------------
// Root layout: fonts, global SEO metadata, structured data, cart provider,
// sticky navbar, footer and the cart drawer.
// ---------------------------------------------------------------------------
import type { Metadata, Viewport } from "next";
import { DM_Sans, Fraunces } from "next/font/google";
import type { ReactNode } from "react";
import { CartProvider } from "@/components/cart/cart-context";
import { CartDrawer } from "@/components/cart/cart-drawer";
import { Footer } from "@/components/layout/footer";
import { Navbar } from "@/components/layout/navbar";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
});

const dmSans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-dmsans",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://alamanahcart.com"),
  title: {
    default: "Al Amanah Cart — Honest Organic Food, Farm to Door",
    template: "%s · Al Amanah Cart",
  },
  description:
    "Certified-organic honey, olive oil, dates, teas and pantry staples sourced directly from small farms. Traceable to the field, delivered fresh to your door.",
  keywords: [
    "organic food",
    "organic grocery delivery",
    "raw honey",
    "cold pressed olive oil",
    "medjool dates",
    "halal organic",
    "farm to table",
    "Al Amanah Cart",
  ],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://alamanahcart.com",
    siteName: "Al Amanah Cart",
    title: "Al Amanah Cart — Honest Organic Food, Farm to Door",
    description:
      "Certified-organic pantry staples sourced from 60+ small farms. Traceable to the field, delivered to your door.",
    images: [
      {
        url: "/images/hero.jpg",
        width: 1200,
        height: 1600,
        alt: "Basket of fresh organic produce from Al Amanah Cart",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Al Amanah Cart — Honest Organic Food",
    description:
      "Certified-organic pantry staples sourced from 60+ small farms. Traceable to the field, delivered to your door.",
    images: ["/images/hero.jpg"],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#16301f",
  width: "device-width",
  initialScale: 1,
};

/** JSON-LD structured data for rich results. */
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Al Amanah Cart",
  url: "https://alamanahcart.com",
  slogan: "Honest food from the earth.",
  contactPoint: {
    "@type": "ContactPoint",
    telephone: "+1-512-555-0134",
    contactType: "customer service",
    email: "hello@alamanahcart.com",
  },
  sameAs: [
    "https://instagram.com/alamanahcart",
    "https://facebook.com/alamanahcart",
    "https://x.com/alamanahcart",
  ],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${dmSans.variable}`}>
      <body className="bg-cream-100 font-sans text-forest-950 antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <CartProvider>
          <Navbar />
          <main id="main-content">{children}</main>
          <Footer />
          <CartDrawer />
        </CartProvider>
      </body>
    </html>
  );
}
