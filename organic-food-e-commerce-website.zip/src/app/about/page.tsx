// ---------------------------------------------------------------------------
// About page: our story, mission, values and milestones. Fully static —
// content lives here as first-class copy rather than in the database.
// ---------------------------------------------------------------------------
import type { Metadata } from "next";
import {
  ArrowRight,
  Handshake,
  Route,
  ShieldCheck,
  Users,
  type LucideIcon,
} from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { CtaBand } from "@/components/home/cta-band";
import { Reveal } from "@/components/shared/reveal";

export const metadata: Metadata = {
  title: "Our Story, Mission & Values",
  description:
    "Al Amanah means 'the trust'. Learn how one honey cooperative in 2016 grew into a family of 60+ farms — and the promise we've never moved an inch.",
  alternates: { canonical: "/about" },
  openGraph: {
    title: "Our Story · Al Amanah Cart",
    description:
      "From one honey cooperative to 60+ partner farms: the story, mission and values behind Al Amanah Cart.",
    images: [{ url: "/images/about.jpg", width: 1200, height: 900, alt: "Farmer's hands holding soil with young seedlings" }],
  },
};

const STATS = [
  { value: "60+", label: "Partner farms" },
  { value: "12k", label: "Happy customers" },
  { value: "4.9★", label: "Average rating" },
  { value: "100%", label: "Certified organic" },
];

const PILLARS: { Icon: LucideIcon; title: string; body: string }[] = [
  {
    Icon: Route,
    title: "Radical Traceability",
    body: "Every jar names its farm, its harvest month and its batch. Ask for the lab report — we'll send it the same day.",
  },
  {
    Icon: Handshake,
    title: "Fair Partnerships",
    body: "We commit to farm contracts a full season ahead and pay on delivery, not on consignment. Farmers plan; you taste it.",
  },
  {
    Icon: ShieldCheck,
    title: "Nothing to Hide",
    body: "No synthetic anything, no 'natural flavors', no greenwashed labels. If we wouldn't serve it to our grandmother, we won't ship it to you.",
  },
  {
    Icon: Users,
    title: "Community First",
    body: "2% of revenue funds school gardens in every city we deliver to. Good food should grow more good food.",
  },
];

const TIMELINE = [
  {
    year: "2016",
    title: "One beekeeper, one promise",
    body: "We start with a single honey cooperative and a rule we still live by: if we can't trace it to a field, we don't sell it.",
  },
  {
    year: "2018",
    title: "Ten farms, first van",
    body: "Olive oil, dates and za'atar join the shelves. Our first refrigerated van means farm-fresh reaches the whole city within 48 hours.",
  },
  {
    year: "2021",
    title: "Zero-waste packing",
    body: "We eliminate plastic from every shipment — recycled paper, compostable liners and plant-based gel packs become the standard.",
  },
  {
    year: "2024",
    title: "60 farms strong",
    body: "The family passes 60 partner farms and 10,000 customers, with batch-level traceability on every single product page.",
  },
  {
    year: "Today",
    title: "Still a promise, not a platform",
    body: "Same rule as day one. Same grandmother test. Just more tables to serve — including, we hope, yours.",
  },
];

export default function AboutPage() {
  return (
    <>
      {/* ------- Story hero ------- */}
      <section className="grain relative overflow-hidden pt-32 pb-16 md:pt-40 md:pb-20">
        <div
          aria-hidden
          className="absolute -top-40 -left-32 size-[30rem] rounded-full bg-honey-300/25 blur-3xl"
        />
        <div className="relative z-[2] mx-auto grid max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-2">
          <Reveal>
            <p className="text-xs font-bold tracking-[0.3em] text-clay-600 uppercase">
              Our story
            </p>
            <h1 className="mt-4 font-display text-5xl leading-[1.03] font-semibold tracking-tight text-balance text-forest-950 md:text-6xl">
              Al Amanah means <em className="text-clay-600 italic">the trust</em> —
              and we keep it.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-forest-700">
              In Arabic, <em>amanah</em> is the thing placed in your care that you
              are honour-bound to protect. When you order from us, your table
              becomes that thing. It&apos;s why we buy full harvests ahead of the
              season, photograph the farms we source from, and answer the phone
              ourselves.
            </p>
            <p className="mt-4 max-w-xl leading-relaxed text-forest-700">
              Nine years ago it was one honey cooperative and a borrowed
              hatchback. Today it&apos;s a family of more than sixty farms,
              orchardists, millers and beekeepers — and twelve thousand kitchens
              that cook with what they grow.
            </p>
          </Reveal>

          <Reveal delay={0.15} className="relative">
            <div
              aria-hidden
              className="absolute -top-6 -right-4 size-36 animate-spin-slow rounded-full border border-dashed border-clay-500/50"
            />
            <div className="relative aspect-[4/3] overflow-hidden rounded-[36px] border-[10px] border-cream-50 shadow-2xl shadow-forest-950/20">
              <Image
                src="/images/about.jpg"
                alt="Farmer's hands cradling dark soil with young green seedlings in golden-hour light"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
          </Reveal>
        </div>
      </section>

      {/* ------- Stats band ------- */}
      <section className="texture-dots bg-forest-950 py-14" aria-label="Company at a glance">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-5 md:grid-cols-4 md:px-8">
          {STATS.map((stat, i) => (
            <Reveal key={stat.label} delay={i * 0.08} y={16}>
              <div className="text-center">
                <p className="font-display text-5xl font-bold text-cream-50 md:text-6xl">
                  {stat.value}
                </p>
                <p className="mt-2 text-xs font-bold tracking-[0.24em] text-forest-300 uppercase">
                  {stat.label}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ------- Mission quote ------- */}
      <section className="mx-auto max-w-4xl px-5 py-20 text-center md:px-8 md:py-28">
        <Reveal>
          <p className="text-xs font-bold tracking-[0.3em] text-clay-600 uppercase">
            Our mission
          </p>
          <blockquote className="mt-6 font-display text-3xl leading-[1.2] font-medium text-balance text-forest-950 md:text-[2.75rem]">
            “To shorten the distance between honest soil and your table — one
            transparent jar at a time.”
          </blockquote>
        </Reveal>
      </section>

      {/* ------- Values grid ------- */}
      <section className="border-y border-forest-900/10 bg-cream-50/70 py-20 md:py-24" aria-label="What we value">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal className="max-w-2xl">
            <p className="text-xs font-bold tracking-[0.3em] text-clay-600 uppercase">
              What we stand for
            </p>
            <h2 className="mt-4 font-display text-4xl leading-[1.06] font-semibold tracking-tight text-forest-950 md:text-5xl">
              Four pillars, <em className="text-clay-600 italic">zero</em> compromises
            </h2>
          </Reveal>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {PILLARS.map(({ Icon, title, body }, i) => (
              <Reveal key={title} delay={i * 0.08} className="h-full">
                <div className="group h-full rounded-[28px] border border-forest-900/10 bg-cream-100 p-6 transition-all duration-500 hover:-translate-y-1.5 hover:bg-forest-900 hover:shadow-xl hover:shadow-forest-950/20">
                  <span className="flex size-12 items-center justify-center rounded-2xl bg-forest-800 text-cream-50 transition-colors duration-500 group-hover:bg-clay-500">
                    <Icon className="size-6" aria-hidden />
                  </span>
                  <h3 className="mt-5 font-display text-xl font-semibold text-forest-950 transition-colors duration-500 group-hover:text-cream-50">
                    {title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-forest-700 transition-colors duration-500 group-hover:text-cream-100/75">
                    {body}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ------- Timeline ------- */}
      <section className="mx-auto max-w-4xl px-5 py-20 md:px-8 md:py-28" aria-label="Our milestones">
        <Reveal className="text-center">
          <p className="text-xs font-bold tracking-[0.3em] text-clay-600 uppercase">
            The road so far
          </p>
          <h2 className="mt-4 font-display text-4xl leading-[1.06] font-semibold tracking-tight text-forest-950 md:text-5xl">
            Nine harvests of keeping promises
          </h2>
        </Reveal>

        <ol className="relative mt-14 space-y-10 border-l-2 border-dashed border-forest-300 pl-8 md:pl-12">
          {TIMELINE.map((item, i) => (
            <Reveal key={item.year} delay={i * 0.06} y={20}>
              <li className="relative">
                <span
                  aria-hidden
                  className="absolute top-1.5 -left-[41px] size-4 rounded-full border-4 border-cream-100 bg-clay-500 md:-left-[57px]"
                />
                <p className="font-display text-sm font-bold tracking-[0.2em] text-clay-600 uppercase">
                  {item.year}
                </p>
                <h3 className="mt-1.5 font-display text-2xl font-semibold text-forest-950">
                  {item.title}
                </h3>
                <p className="mt-2 max-w-2xl leading-relaxed text-forest-700">
                  {item.body}
                </p>
              </li>
            </Reveal>
          ))}
        </ol>

        <Reveal className="mt-14 text-center">
          <Link
            href="/products"
            className="focus-ring group inline-flex items-center gap-2.5 rounded-full bg-forest-800 px-8 py-4 text-sm font-bold text-cream-50 transition hover:bg-forest-900"
          >
            Taste what the farms grew
            <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden />
          </Link>
        </Reveal>
      </section>

      <CtaBand />
    </>
  );
}
