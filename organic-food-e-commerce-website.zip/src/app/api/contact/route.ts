// ---------------------------------------------------------------------------
// POST /api/contact — stores a contact-form message in PostgreSQL.
// Body: { name, email, subject?, message }
// ---------------------------------------------------------------------------
import { NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim();
    const subject = String(body.subject ?? "").trim();
    const message = String(body.message ?? "").trim();

    // Basic validation — keep it human-friendly.
    if (!name || name.length > 120) {
      return NextResponse.json({ error: "A valid name is required." }, { status: 400 });
    }
    if (!EMAIL_RE.test(email)) {
      return NextResponse.json({ error: "A valid email is required." }, { status: 400 });
    }
    if (!message || message.length > 5000) {
      return NextResponse.json({ error: "Please include a message." }, { status: 400 });
    }

    await db.insert(contactMessages).values({ name, email, subject, message });

    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (err) {
    console.error("[api/contact] failed:", err);
    return NextResponse.json(
      { error: "Could not send your message right now." },
      { status: 500 },
    );
  }
}
