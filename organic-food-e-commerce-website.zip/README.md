# 🌿 Al Amanah Cart — Honest Organic Food, Farm to Door

A complete, responsive e-commerce website for **Al Amanah Cart**, built with a
modern fullstack toolset and designed to an agency-level standard: editorial
serif typography, an earthy cream/forest/clay palette, butter-smooth scroll
animations, a working cart with checkout, and a PostgreSQL-backed catalog.

---

## ✨ Features

- **4 pages** — Home (hero, featured products, values, story, reviews, FAQ, CTA), Shop, About, Contact
- **Working cart** — add-to-cart, quantity controls, free-shipping progress bar, slide-over drawer, checkout that posts orders to the database and returns a reference number
- **Database-backed content** — products, reviews and FAQs are served from PostgreSQL via Drizzle ORM (with graceful bundled fallbacks)
- **Contact form** — validated and persisted to the database with success/error states
- **Fully responsive** — mobile drawer navigation, horizontally scrolling filter chips, fluid typography
- **Sticky glass navbar** — transparent over the hero, frosted on scroll
- **Scroll animations** — physics-based reveals powered by Framer Motion; pure-CSS marquee; parallax hero
- **SEO baked in** — per-page metadata, Open Graph/Twitter cards, JSON-LD structured data, `sitemap.xml`, `robots.txt`, semantic headings and descriptive alt text
- **Accessible** — focus rings, ARIA labels, keyboard-friendly accordion and drawer

## 🧱 Tech Stack

| Layer     | Choice                                        |
| --------- | --------------------------------------------- |
| Framework | Next.js 16 (App Router, RSC)                  |
| Language  | TypeScript                                    |
| Styling   | Tailwind CSS v4 (`@theme` design tokens)      |
| Animation | Framer Motion                                 |
| Icons     | Lucide                                        |
| Database  | PostgreSQL + Drizzle ORM                      |
| Fonts     | Fraunces (display serif) + DM Sans (body)     |

## 📁 Project Structure

```
├── scripts/
│   └── seed.mjs                  # Idempotent database seed (node scripts/seed.mjs)
├── public/images/                # Art-directed AI imagery (hero, about, 8 products)
├── src/
│   ├── app/
│   │   ├── layout.tsx            # Fonts, global SEO, JSON-LD, providers
│   │   ├── page.tsx              # Home
│   │   ├── products/page.tsx     # Shop (SSG-shell + client explorer)
│   │   ├── about/page.tsx        # Story, mission, values, timeline
│   │   ├── contact/page.tsx      # Info panel, form, OpenStreetMap embed
│   │   ├── sitemap.ts / robots.ts
│   │   ├── globals.css           # Tailwind v4 theme, textures, marquee keyframes
│   │   └── api/
│   │       ├── products/route.ts # GET catalog
│   │       ├── reviews/route.ts  # GET testimonials
│   │       ├── faqs/route.ts     # GET FAQs
│   │       ├── contact/route.ts  # POST contact message
│   │       ├── orders/route.ts   # POST order (server-side re-pricing)
│   │       └── health/route.ts   # DB healthcheck
│   ├── components/
│   │   ├── cart/                 # Cart context (localStorage) + drawer/checkout
│   │   ├── home/                 # Hero, featured, values, story, reviews, FAQ, CTA
│   │   ├── products/             # ProductCard + filterable explorer
│   │   ├── contact/              # Contact form (client island)
│   │   ├── layout/               # Navbar, footer, newsletter
│   │   └── shared/               # Reveal, Stars, Marquee, section heading, icons
│   ├── db/
│   │   ├── schema.ts             # products, reviews, faqs, contact_messages, orders
│   │   └── index.ts              # Drizzle client
│   └── lib/
│       ├── data.ts               # DB queries with fallbacks
│       ├── fallback-data.ts      # Seed content (mirrors the seed script)
│       └── utils.ts              # cn(), formatPrice(), orderNumber(), initials()
```

## 🚀 Setup Instructions

### 1. Prerequisites

- Node.js 18.18+ (or 20+)
- A PostgreSQL database (the sandbox provides one and sets `DATABASE_URL` in `.env`)

### 2. Install dependencies

```bash
npm install
```

### 3. Configure the environment

Create a `.env` file in the project root (already present in the sandbox):

```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
```

### 4. Create the tables and seed the catalog

```bash
npx drizzle-kit push   # applies src/db/schema.ts to the database
node scripts/seed.mjs  # inserts products, reviews and FAQs (idempotent)
```

> No database handy? The site still renders fully — every query has a
> bundled fallback with the same content.

### 5. Run it

```bash
npm run dev    # development on http://localhost:3000
# or
npm run build && npm run start   # production
```

## 🔌 API Reference

| Method | Route            | Purpose                                             |
| ------ | ---------------- | --------------------------------------------------- |
| GET    | `/api/products`  | Full catalog                                        |
| GET    | `/api/reviews`   | Testimonials                                        |
| GET    | `/api/faqs`      | FAQs                                                |
| POST   | `/api/contact`   | `{ name, email, subject?, message }`                |
| POST   | `/api/orders`    | `{ customerName, customerEmail, items[] }` — prices re-derived server-side |
| GET    | `/api/health`    | Database healthcheck                                |

## 🎨 Design Notes

- **Palette** — warm cream canvas (`#f6f0e2`), deep forest greens, clay orange
  and honey gold accents; film-grain and dot textures are pure CSS/SVG.
- **Type** — Fraunces for editorial headlines (with italic accent words),
  DM Sans for UI copy.
- **Motion** — `[0.22, 1, 0.36, 1]` easing everywhere; reveals fire once,
  `-80px` before entering the viewport.

---

© Al Amanah Cart. Grown with care, shipped with *amanah*.
